// SPDX-License-Identifier: GPL-2.0-only
/*
 * IOMMU API for RISC-V architected Ziommu implementations.
 *
 * Copyright © 2022-2023 Rivos Inc.
 * Copyright © 2023 FORTH-ICS/CARV
 *
 * Authors
 *	Tomasz Jeznach <tjeznach@rivosinc.com>
 *	Nick Kossifidis <mick@ics.forth.gr>
 */

#define pr_fmt(fmt) KBUILD_MODNAME ": " fmt

#include <linux/bitfield.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/compiler.h>
#include <linux/pci.h>
#include <linux/pci-ats.h>
#include <linux/init.h>
#include <linux/atomic.h>
#include <linux/completion.h>
#include <linux/uaccess.h>
#include <linux/iommu.h>
#include <linux/irqdomain.h>
#include <linux/platform_device.h>
#include <linux/dma-map-ops.h>
#include <linux/riscv_iommu_research.h>
#include <linux/sched/mm.h>
#include <asm/page.h>

#include "../dma-iommu.h"
#include "../iommu-sva.h"
#include "iommu.h"

#include <asm/csr.h>
#include <asm/delay.h>

MODULE_DESCRIPTION("IOMMU driver for RISC-V architected Ziommu implementations");
MODULE_AUTHOR("Tomasz Jeznach <tjeznach@rivosinc.com>");
MODULE_AUTHOR("Nick Kossifidis <mick@ics.forth.gr>");
MODULE_ALIAS("riscv-iommu");
MODULE_LICENSE("GPL v2");

/* Global IOMMU params. */
static int ddt_mode = RISCV_IOMMU_DDTP_MODE_1LVL;
module_param(ddt_mode, int, 0644);
MODULE_PARM_DESC(ddt_mode, "Device Directory Table mode.");

static int cmdq_length = 128;
module_param(cmdq_length, int, 0644);
MODULE_PARM_DESC(cmdq_length, "Command queue length.");

static int fltq_length = 128;
module_param(fltq_length, int, 0644);
MODULE_PARM_DESC(fltq_length, "Fault queue length.");

static int priq_length = 128;
module_param(priq_length, int, 0644);
MODULE_PARM_DESC(priq_length, "Page request interface queue length.");

/* TODO: Enable MSI remapping */
#define RISCV_IMSIC_BASE	0x28000000

/* 1 second */
#define RISCV_IOMMU_TIMEOUT	riscv_timebase

/* RISC-V IOMMU PPN <> PHYS address conversions, PHYS <=> PPN[53:10] */
#define phys_to_ppn(va)  (((va) >> 2) & (((1ULL << 44) - 1) << 10))
#define ppn_to_phys(pn)	 (((pn) << 2) & (((1ULL << 44) - 1) << 12))

#define iommu_domain_to_riscv(iommu_domain) \
    container_of(iommu_domain, struct riscv_iommu_domain, domain)

#define iommu_device_to_riscv(iommu_device) \
    container_of(iommu_device, struct riscv_iommu, iommu)

static const struct iommu_domain_ops riscv_iommu_domain_ops;
static const struct iommu_ops riscv_iommu_ops;

/* Keep ordinary domain PSCIDs disjoint from real process PASIDs. */
#define RISCV_IOMMU_DOMAIN_PSCID_MIN BIT(19)
#define RISCV_IOMMU_DOMAIN_PSCID_MAX (BIT(20) - 1)
static DEFINE_IDA(riscv_iommu_pscids);
static DEFINE_IDA(riscv_iommu_gscids);
/* Serializes list membership, domain lifetime and endpoint transitions. */
static DEFINE_MUTEX(riscv_iommu_domain_mutex);
static bool research;
module_param(research, bool, 0400);
MODULE_PARM_DESC(research, "Enable restricted synchronous DID10/11 Sv39 research API");

/*
 * Common queue management routines
 */

/* Note: offsets are the same for all queues */
#define Q_HEAD(q) ((q)->qbr + (RISCV_IOMMU_REG_CQH - RISCV_IOMMU_REG_CQB))
#define Q_TAIL(q) ((q)->qbr + (RISCV_IOMMU_REG_CQT - RISCV_IOMMU_REG_CQB))

static unsigned riscv_iommu_queue_consume(struct riscv_iommu_device *iommu,
					  struct riscv_iommu_queue *q, unsigned *ready)
{
	u32 tail = riscv_iommu_readl(iommu, Q_TAIL(q));
	*ready = q->lui;

	BUG_ON(q->cnt <= tail);
	if (q->lui <= tail)
		return tail - q->lui;
	return q->cnt - q->lui;
}

static void riscv_iommu_queue_release(struct riscv_iommu_device *iommu,
				      struct riscv_iommu_queue *q, unsigned count)
{
	q->lui = (q->lui + count) & (q->cnt - 1);
	riscv_iommu_writel(iommu, Q_HEAD(q), q->lui);
}

static u32 riscv_iommu_queue_ctrl(struct riscv_iommu_device *iommu,
				  struct riscv_iommu_queue *q, u32 val)
{
	cycles_t end_cycles = RISCV_IOMMU_TIMEOUT + get_cycles();

	riscv_iommu_writel(iommu, q->qcr, val);
	do {
		val = riscv_iommu_readl(iommu, q->qcr);
		if (!(val & RISCV_IOMMU_QUEUE_BUSY))
			break;
		cpu_relax();
	} while (get_cycles() < end_cycles);

	return val;
}

static void riscv_iommu_queue_free(struct riscv_iommu_device *iommu,
				   struct riscv_iommu_queue *q)
{
	size_t size = q->len * q->cnt;

	riscv_iommu_queue_ctrl(iommu, q, 0);

	if (q->base) {
		if (q->in_iomem)
			iounmap(q->base);
		else
			dmam_free_coherent(iommu->dev, size, q->base, q->base_dma);
	}
	if (q->irq)
		free_irq(q->irq, q);
}

static irqreturn_t riscv_iommu_cmdq_irq_check(int irq, void *data);
static irqreturn_t riscv_iommu_cmdq_process(int irq, void *data);
static irqreturn_t riscv_iommu_fltq_irq_check(int irq, void *data);
static irqreturn_t riscv_iommu_fltq_process(int irq, void *data);
static irqreturn_t riscv_iommu_priq_irq_check(int irq, void *data);
static irqreturn_t riscv_iommu_priq_process(int irq, void *data);

static int riscv_iommu_queue_init(struct riscv_iommu_device *iommu, int queue_id)
{
	struct device *dev = iommu->dev;
	struct riscv_iommu_queue *q = NULL;
	size_t queue_size = 0;
	irq_handler_t irq_check;
	irq_handler_t irq_process;
	const char *name;
	int count = 0;
	int irq = 0;
	unsigned order = 0;
	u64 qbr_val = 0;
	u64 qbr_readback = 0;
	u64 qbr_paddr = 0;
	int ret = 0;

	switch (queue_id) {
	case RISCV_IOMMU_COMMAND_QUEUE:
		q = &iommu->cmdq;
		q->len = sizeof(struct riscv_iommu_command);
		count = iommu->cmdq_len;
		irq = iommu->irq_cmdq;
		irq_check = riscv_iommu_cmdq_irq_check;
		irq_process = riscv_iommu_cmdq_process;
		q->qbr = RISCV_IOMMU_REG_CQB;
		q->qcr = RISCV_IOMMU_REG_CQCSR;
		name = "cmdq";
		break;
	case RISCV_IOMMU_FAULT_QUEUE:
		q = &iommu->fltq;
		q->len = sizeof(struct riscv_iommu_fq_record);
		count = iommu->fltq_len;
		irq = iommu->irq_fltq;
		irq_check = riscv_iommu_fltq_irq_check;
		irq_process = riscv_iommu_fltq_process;
		q->qbr = RISCV_IOMMU_REG_FQB;
		q->qcr = RISCV_IOMMU_REG_FQCSR;
		name = "fltq";
		break;
	case RISCV_IOMMU_PAGE_REQUEST_QUEUE:
		q = &iommu->priq;
		q->len = sizeof(struct riscv_iommu_pq_record);
		count = iommu->priq_len;
		irq = iommu->irq_priq;
		irq_check = riscv_iommu_priq_irq_check;
		irq_process = riscv_iommu_priq_process;
		q->qbr = RISCV_IOMMU_REG_PQB;
		q->qcr = RISCV_IOMMU_REG_PQCSR;
		name = "priq";
		break;
	default:
		dev_err(dev, "invalid queue interrupt index in queue_init!\n");
		return -EINVAL;
	}

	/* Polling not implemented */
	if (!irq)
		return -ENODEV;

	/* Allocate queue in memory and set the base register */
	order = ilog2(count);
	do {
		queue_size = q->len * (1ULL << order);
		q->base = dmam_alloc_coherent(dev, queue_size, &q->base_dma, GFP_KERNEL);
		if (q->base || queue_size < PAGE_SIZE)
			break;

		order--;
	} while (1);

	if (!q->base) {
		dev_err(dev, "failed to allocate %s queue (cnt: %u)\n", name, count);
		return -ENOMEM;
	}

	q->cnt = 1ULL << order;

	qbr_val = phys_to_ppn(q->base_dma) |
	    FIELD_PREP(RISCV_IOMMU_QUEUE_SIZE_FIELD, order - 1);

	riscv_iommu_writeq(iommu, q->qbr, qbr_val);

	/*
	 * Queue base registers are WARL, so it's possible that whatever we wrote
	 * there was illegal/not supported by the hw in which case we need to make
	 * sure we set a supported PPN and/or queue size.
	 */
	qbr_readback = riscv_iommu_readq(iommu, q->qbr);
	if (qbr_readback == qbr_val)
		goto irq;

	dmam_free_coherent(dev, queue_size, q->base, q->base_dma);

	/* Get supported queue size */
	order = FIELD_GET(RISCV_IOMMU_QUEUE_SIZE_FIELD, qbr_readback) + 1;
	q->cnt = 1ULL << order;
	queue_size = q->len * q->cnt;

	/*
	 * In case we also failed to set PPN, it means the field is hardcoded and the
	 * queue resides in I/O memory instead, so get its physical address and
	 * ioremap it.
	 */
	qbr_paddr = ppn_to_phys(qbr_readback);
	if (qbr_paddr != q->base_dma) {
		dev_info(dev,
			 "hardcoded ppn in %s base register, using io memory for the queue\n",
			 name);
		dev_info(dev, "queue length for %s set to %i\n", name, q->cnt);
		q->in_iomem = true;
		q->base = ioremap(qbr_paddr, queue_size);
		if (!q->base) {
			dev_err(dev, "failed to map %s queue (cnt: %u)\n", name, q->cnt);
			return -ENOMEM;
		}
		q->base_dma = qbr_paddr;
	} else {
		/*
		 * We only failed to set the queue size, re-try to allocate memory with
		 * the queue size supported by the hw.
		 */
		dev_info(dev, "hardcoded queue size in %s base register\n", name);
		dev_info(dev, "retrying with queue length: %i\n", q->cnt);
		q->base = dmam_alloc_coherent(dev, queue_size, &q->base_dma, GFP_KERNEL);
		if (!q->base) {
			dev_err(dev, "failed to allocate %s queue (cnt: %u)\n",
				name, q->cnt);
			return -ENOMEM;
		}
	}

	qbr_val = phys_to_ppn(q->base_dma) |
	    FIELD_PREP(RISCV_IOMMU_QUEUE_SIZE_FIELD, order - 1);
	riscv_iommu_writeq(iommu, q->qbr, qbr_val);

	/* Final check to make sure hw accepted our write */
	qbr_readback = riscv_iommu_readq(iommu, q->qbr);
	if (qbr_readback != qbr_val) {
		dev_err(dev, "failed to set base register for %s\n", name);
		goto fail;
	}

 irq:
	if (request_threaded_irq(irq, irq_check, irq_process, IRQF_ONESHOT | IRQF_SHARED,
				 dev_name(dev), q)) {
		dev_err(dev, "fail to request irq %d for %s\n", irq, name);
		goto fail;
	}

	q->irq = irq;

	/* Note: All RIO_xQ_EN/IE fields are in the same offsets */
	ret =
	    riscv_iommu_queue_ctrl(iommu, q,
				   RISCV_IOMMU_QUEUE_ENABLE |
				   RISCV_IOMMU_QUEUE_INTR_ENABLE);
	if (ret & RISCV_IOMMU_QUEUE_BUSY) {
		dev_err(dev, "%s init timeout\n", name);
		ret = -EBUSY;
		goto fail;
	}

	return 0;

 fail:
	riscv_iommu_queue_free(iommu, q);
	return 0;
}

/*
 * I/O MMU Command queue chapter 3.1
 */

static inline void riscv_iommu_cmd_inval_vma(struct riscv_iommu_command *cmd)
{
	cmd->dword0 =
	    FIELD_PREP(RISCV_IOMMU_CMD_OPCODE,
		       RISCV_IOMMU_CMD_IOTINVAL_OPCODE) | FIELD_PREP(RISCV_IOMMU_CMD_FUNC,
								     RISCV_IOMMU_CMD_IOTINVAL_FUNC_VMA);
	cmd->dword1 = 0;
}

static void riscv_iommu_cmd_inval_gvma(struct riscv_iommu_command *cmd)
{
	cmd->dword0 =
	    FIELD_PREP(RISCV_IOMMU_CMD_OPCODE,
		       RISCV_IOMMU_CMD_IOTINVAL_OPCODE) | FIELD_PREP(RISCV_IOMMU_CMD_FUNC,
								     RISCV_IOMMU_CMD_IOTINVAL_FUNC_GVMA);
	cmd->dword1 = 0;
}

static inline void riscv_iommu_cmd_inval_set_addr(struct riscv_iommu_command *cmd,
						  u64 addr)
{
	cmd->dword0 |= RISCV_IOMMU_CMD_IOTINVAL_AV;
	cmd->dword1 = addr;
}

static inline void riscv_iommu_cmd_inval_set_pscid(struct riscv_iommu_command *cmd,
						   unsigned pscid)
{
	cmd->dword0 |= FIELD_PREP(RISCV_IOMMU_CMD_IOTINVAL_PSCID, pscid) |
	    RISCV_IOMMU_CMD_IOTINVAL_PSCV;
}

static inline void riscv_iommu_cmd_inval_set_gscid(struct riscv_iommu_command *cmd,
						   unsigned gscid)
{
	cmd->dword0 |= FIELD_PREP(RISCV_IOMMU_CMD_IOTINVAL_GSCID, gscid) |
	    RISCV_IOMMU_CMD_IOTINVAL_GV;
}

static inline void riscv_iommu_cmd_iofence(struct riscv_iommu_command *cmd)
{
	cmd->dword0 = FIELD_PREP(RISCV_IOMMU_CMD_OPCODE, RISCV_IOMMU_CMD_IOFENCE_OPCODE) |
	    FIELD_PREP(RISCV_IOMMU_CMD_FUNC, RISCV_IOMMU_CMD_IOFENCE_FUNC_C);
	cmd->dword1 = 0;
}

static inline void riscv_iommu_cmd_iofence_set_av(struct riscv_iommu_command *cmd,
						  u64 addr, u32 data)
{
	cmd->dword0 = FIELD_PREP(RISCV_IOMMU_CMD_OPCODE, RISCV_IOMMU_CMD_IOFENCE_OPCODE) |
	    FIELD_PREP(RISCV_IOMMU_CMD_FUNC, RISCV_IOMMU_CMD_IOFENCE_FUNC_C) |
	    FIELD_PREP(RISCV_IOMMU_CMD_IOFENCE_DATA, data) | RISCV_IOMMU_CMD_IOFENCE_AV;
	cmd->dword1 = (addr >> 2);
}

static inline void riscv_iommu_cmd_iodir_inval_ddt(struct riscv_iommu_command *cmd)
{
	cmd->dword0 = FIELD_PREP(RISCV_IOMMU_CMD_OPCODE, RISCV_IOMMU_CMD_IODIR_OPCODE) |
	    FIELD_PREP(RISCV_IOMMU_CMD_FUNC, RISCV_IOMMU_CMD_IODIR_FUNC_INVAL_DDT);
	cmd->dword1 = 0;
}

static inline void riscv_iommu_cmd_iodir_inval_pdt(struct riscv_iommu_command *cmd)
{
	cmd->dword0 = FIELD_PREP(RISCV_IOMMU_CMD_OPCODE, RISCV_IOMMU_CMD_IODIR_OPCODE) |
	    FIELD_PREP(RISCV_IOMMU_CMD_FUNC, RISCV_IOMMU_CMD_IODIR_FUNC_INVAL_PDT);
	cmd->dword1 = 0;
}

static inline void riscv_iommu_cmd_iodir_set_did(struct riscv_iommu_command *cmd,
						 unsigned devid)
{
	cmd->dword0 |=
	    FIELD_PREP(RISCV_IOMMU_CMD_IODIR_DID, devid) | RISCV_IOMMU_CMD_IODIR_DV;
}

static inline void riscv_iommu_cmd_iodir_set_pid(struct riscv_iommu_command *cmd,
						 unsigned pasid)
{
	cmd->dword0 |= FIELD_PREP(RISCV_IOMMU_CMD_IODIR_PID, pasid);
}

static void riscv_iommu_cmd_ats_inval(struct riscv_iommu_command *cmd)
{
	cmd->dword0 = FIELD_PREP(RISCV_IOMMU_CMD_OPCODE, RISCV_IOMMU_CMD_ATS_OPCODE) |
	    FIELD_PREP(RISCV_IOMMU_CMD_FUNC, RISCV_IOMMU_CMD_ATS_FUNC_INVAL);
	cmd->dword1 = 0;
}

static inline void riscv_iommu_cmd_ats_prgr(struct riscv_iommu_command *cmd)
{
	cmd->dword0 = FIELD_PREP(RISCV_IOMMU_CMD_OPCODE, RISCV_IOMMU_CMD_ATS_OPCODE) |
	    FIELD_PREP(RISCV_IOMMU_CMD_FUNC, RISCV_IOMMU_CMD_ATS_FUNC_PRGR);
	cmd->dword1 = 0;
}

static void riscv_iommu_cmd_ats_set_rid(struct riscv_iommu_command *cmd, u32 rid)
{
	cmd->dword0 |= FIELD_PREP(RISCV_IOMMU_CMD_ATS_RID, rid);
}

static void riscv_iommu_cmd_ats_set_pid(struct riscv_iommu_command *cmd, u32 pid)
{
	cmd->dword0 |= FIELD_PREP(RISCV_IOMMU_CMD_ATS_PID, pid) | RISCV_IOMMU_CMD_ATS_PV;
}

static void riscv_iommu_cmd_ats_set_dseg(struct riscv_iommu_command *cmd, u8 seg)
{
	cmd->dword0 |= FIELD_PREP(RISCV_IOMMU_CMD_ATS_DSEG, seg) | RISCV_IOMMU_CMD_ATS_DSV;
}

static void riscv_iommu_cmd_ats_set_payload(struct riscv_iommu_command *cmd, u64 payload)
{
	cmd->dword1 = payload;
}

/* Prepare the ATS invalidation payload */
static unsigned long riscv_iommu_ats_inval_payload(unsigned long start,
						   unsigned long end, bool global_inv)
{
	size_t len = end - start + 1;
	unsigned long payload = 0;

	/*
	 * PCI Express specification
	 * Section 10.2.3.2 Translation Range Size (S) Field
	 */
	if (len < PAGE_SIZE)
		len = PAGE_SIZE;
	else
		len = __roundup_pow_of_two(len);

	payload = (start & ~(len - 1)) | (((len - 1) >> 12) << 11);

	if (global_inv)
		payload |= RISCV_IOMMU_CMD_ATS_INVAL_G;

	return payload;
}

/* Prepare the ATS invalidation payload for all translations to be invalidated. */
static unsigned long riscv_iommu_ats_inval_all_payload(bool global_inv)
{
	unsigned long payload = GENMASK_ULL(62, 11);

	if (global_inv)
		payload |= RISCV_IOMMU_CMD_ATS_INVAL_G;

	return payload;
}

// Prepare the ATS "Page Request Group Response" payload
static unsigned long riscv_iommu_ats_prgr_payload(u16 dest_id, u8 resp_code, u16 grp_idx)
{
	return FIELD_PREP(RISCV_IOMMU_CMD_ATS_PRGR_DST_ID, dest_id) |
	    FIELD_PREP(RISCV_IOMMU_CMD_ATS_PRGR_RESP_CODE, resp_code) |
	    FIELD_PREP(RISCV_IOMMU_CMD_ATS_PRGR_PRG_INDEX, grp_idx);
}

/* TODO: Convert into lock-less MPSC implementation. */
static bool riscv_iommu_post_sync(struct riscv_iommu_device *iommu,
				  struct riscv_iommu_command *cmd, bool sync)
{
	u32 head, tail, next, last;
	unsigned long flags;

	spin_lock_irqsave(&iommu->cq_lock, flags);
	if (iommu->research_cq_owned || iommu->research_cq_poisoned) {
		/* An unexpected poster invalidates exclusive-history acceptance. */
		if (iommu->research_cq_owned)
			atomic64_inc(&iommu->cq_error_seq);
		spin_unlock_irqrestore(&iommu->cq_lock, flags);
		return false;
	}
	head = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQH) & (iommu->cmdq.cnt - 1);
	tail = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQT) & (iommu->cmdq.cnt - 1);
	last = iommu->cmdq.lui;
	if (tail != last || iommu->cq_posted == U64_MAX) {
		spin_unlock_irqrestore(&iommu->cq_lock, flags);
		return false;
	}

	next = (last + 1) & (iommu->cmdq.cnt - 1);
	if (next != head) {
		struct riscv_iommu_command *ptr = iommu->cmdq.base;
		ptr[last] = *cmd;
		iommu->cq_posted++;
		wmb();
		riscv_iommu_writel(iommu, RISCV_IOMMU_REG_CQT, next);
		iommu->cmdq.lui = next;
	}

	spin_unlock_irqrestore(&iommu->cq_lock, flags);

	if (sync && head != next) {
		cycles_t start_time = get_cycles();
		while (1) {
			last = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQH) &
			    (iommu->cmdq.cnt - 1);
			if (head < next && last >= next)
				break;
			if (head > next && last < head && last >= next)
				break;
			if (RISCV_IOMMU_TIMEOUT < (get_cycles() - start_time)) {
				dev_err(iommu->dev, "IOFENCE TIMEOUT\n");
				return false;
			}
			cpu_relax();
		}
	}

	return next != head;
}

static bool riscv_iommu_post(struct riscv_iommu_device *iommu,
			     struct riscv_iommu_command *cmd)
{
	return riscv_iommu_post_sync(iommu, cmd, false);
}

static bool riscv_iommu_iodir_inv_devid(struct riscv_iommu_device *iommu, unsigned devid)
{
	struct riscv_iommu_command cmd;
	riscv_iommu_cmd_iodir_inval_ddt(&cmd);
	riscv_iommu_cmd_iodir_set_did(&cmd, devid);
	return riscv_iommu_post(iommu, &cmd);
}

static bool riscv_iommu_iodir_inv_pasid(struct riscv_iommu_device *iommu,
					unsigned devid, unsigned pasid)
{
	struct riscv_iommu_command cmd;
	riscv_iommu_cmd_iodir_inval_pdt(&cmd);
	riscv_iommu_cmd_iodir_set_did(&cmd, devid);
	riscv_iommu_cmd_iodir_set_pid(&cmd, pasid);
	return riscv_iommu_post(iommu, &cmd);
}

static bool riscv_iommu_iofence_sync(struct riscv_iommu_device *iommu)
{
	struct riscv_iommu_command cmd;
	riscv_iommu_cmd_iofence(&cmd);
	return riscv_iommu_post_sync(iommu, &cmd, true);
}

static void riscv_iommu_mm_invalidate(struct mmu_notifier *mn,
				      struct mm_struct *mm, unsigned long start,
				      unsigned long end)
{
	struct riscv_iommu_command cmd;
	struct riscv_iommu_endpoint *endpoint;
	struct riscv_iommu_domain *domain =
	    container_of(mn, struct riscv_iommu_domain, mn);
	unsigned long iova;
	/*
	 * The mm_types defines vm_end as the first byte after the end address,
	 * different from IOMMU subsystem using the last address of an address
	 * range. So do a simple translation here by updating what end means.
	 */
	unsigned long payload = riscv_iommu_ats_inval_payload(start, end - 1, true);

	/* TODO: cleanup GSCID/PSCID passing */
	riscv_iommu_cmd_inval_vma(&cmd);
	riscv_iommu_cmd_inval_set_gscid(&cmd, 0);
	riscv_iommu_cmd_inval_set_pscid(&cmd, domain->pscid);
	if (end > start) {
		/* Cover only the range that is needed */
		for (iova = start; iova < end; iova += PAGE_SIZE) {
			riscv_iommu_cmd_inval_set_addr(&cmd, iova);
			riscv_iommu_post(domain->iommu, &cmd);
		}
	} else {
		riscv_iommu_post(domain->iommu, &cmd);
	}

	riscv_iommu_iofence_sync(domain->iommu);

	/* ATS invalidation for every device and for specific translation range. */
	list_for_each_entry(endpoint, &domain->endpoints, domains) {
		if (!endpoint->pasid_enabled)
			continue;

		riscv_iommu_cmd_ats_inval(&cmd);
		riscv_iommu_cmd_ats_set_dseg(&cmd, endpoint->domid);
		riscv_iommu_cmd_ats_set_rid(&cmd, endpoint->devid);
		riscv_iommu_cmd_ats_set_pid(&cmd, domain->pscid);
		riscv_iommu_cmd_ats_set_payload(&cmd, payload);
		riscv_iommu_post(domain->iommu, &cmd);
	}
	riscv_iommu_iofence_sync(domain->iommu);
}

static void riscv_iommu_mm_release(struct mmu_notifier *mn, struct mm_struct *mm)
{
	/* TODO: removed from notifier, cleanup PSCID mapping, flush IOTLB */
}

static const struct mmu_notifier_ops riscv_iommu_mmuops = {
	.release = riscv_iommu_mm_release,
	.invalidate_range = riscv_iommu_mm_invalidate,
};

/* Command queue primary interrupt handler */
static irqreturn_t riscv_iommu_cmdq_irq_check(int irq, void *data)
{
	struct riscv_iommu_queue *q = (struct riscv_iommu_queue *)data;
	struct riscv_iommu_device *iommu =
	    container_of(q, struct riscv_iommu_device, cmdq);
	u32 ipsr = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_IPSR);
	if (ipsr & RISCV_IOMMU_IPSR_CIP)
		return IRQ_WAKE_THREAD;
	return IRQ_NONE;
}

/* Command queue interrupt hanlder thread function */
static irqreturn_t riscv_iommu_cmdq_process(int irq, void *data)
{
	struct riscv_iommu_queue *q = (struct riscv_iommu_queue *)data;
	struct riscv_iommu_device *iommu;
	unsigned ctrl;

	iommu = container_of(q, struct riscv_iommu_device, cmdq);
	/* Research owns the complete error/recovery history until certification. */
	spin_lock_irq(&iommu->cq_lock);
	if (iommu->research_cq_owned || iommu->research_cq_poisoned) {
		riscv_iommu_writel(iommu, RISCV_IOMMU_REG_IPSR,
				 RISCV_IOMMU_IPSR_CIP);
		spin_unlock_irq(&iommu->cq_lock);
		return IRQ_HANDLED;
	}

	/* Error reporting, clear error reports if any. */
	ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQCSR);
	if (ctrl & (RISCV_IOMMU_CQCSR_CQMF |
		    RISCV_IOMMU_CQCSR_CMD_TO | RISCV_IOMMU_CQCSR_CMD_ILL)) {
		/*
		 * Publish the error generation before the (relaxed) MMIO clear,
		 * so an observer that reads a clean CQCSR afterwards also sees
		 * the bumped generation.
		 */
		atomic64_inc(&iommu->cq_error_seq);
		wmb();
		riscv_iommu_writel(iommu, RISCV_IOMMU_REG_CQCSR, ctrl);
		dev_warn_ratelimited(iommu->dev,
				     "Command queue error: fault: %d tout: %d err: %d\n",
				     !!(ctrl & RISCV_IOMMU_CQCSR_CQMF),
				     !!(ctrl & RISCV_IOMMU_CQCSR_CMD_TO),
				     !!(ctrl & RISCV_IOMMU_CQCSR_CMD_ILL));
	}

	/* Clear fault interrupt pending. */
	riscv_iommu_writel(iommu, RISCV_IOMMU_REG_IPSR, RISCV_IOMMU_IPSR_CIP);
	spin_unlock_irq(&iommu->cq_lock);

	return IRQ_HANDLED;
}

/*
 * Fault/event queue, chapter 3.2
 */

static void riscv_iommu_fault_report(struct riscv_iommu_device *iommu,
				     struct riscv_iommu_fq_record *event)
{
	unsigned err, devid;
	u64 iotval, iotval2;

	err = FIELD_GET(RISCV_IOMMU_FQ_HDR_CAUSE, event->hdr);
	devid = FIELD_GET(RISCV_IOMMU_FQ_HDR_DID, event->hdr);
	iotval = event->iotval;
	iotval2 = event->iotval2;
	
	dev_warn_ratelimited(iommu->dev, "F: %d | DID: %d\n",
						err, devid);
	dev_warn_ratelimited(iommu->dev, "iotval: %llx\n",
						iotval);
	dev_warn_ratelimited(iommu->dev, "iotval2: %llx\n",
						iotval2);
}

/* Fault/event queue primary interrupt handler */
static irqreturn_t riscv_iommu_fltq_irq_check(int irq, void *data)
{
	struct riscv_iommu_queue *q = (struct riscv_iommu_queue *)data;
	struct riscv_iommu_device *iommu =
	    container_of(q, struct riscv_iommu_device, fltq);
	u32 ipsr = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_IPSR);
	if (ipsr & RISCV_IOMMU_IPSR_FIP)
		return IRQ_WAKE_THREAD;
	return IRQ_NONE;
}

/* Fault queue interrupt hanlder thread function */
static irqreturn_t riscv_iommu_fltq_process(int irq, void *data)
{
	struct riscv_iommu_queue *q = (struct riscv_iommu_queue *)data;
	struct riscv_iommu_device *iommu;
	struct riscv_iommu_fq_record *events;
	unsigned cnt, len, idx, ctrl;

	iommu = container_of(q, struct riscv_iommu_device, fltq);
	events = (struct riscv_iommu_fq_record *)q->base;

	/* Error reporting, clear error reports if any. */
	ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_FQCSR);
	if (ctrl & (RISCV_IOMMU_FQCSR_FQMF | RISCV_IOMMU_FQCSR_FWOF)) {
		riscv_iommu_queue_ctrl(iommu, &iommu->fltq, ctrl);
		dev_warn_ratelimited(iommu->dev,
				     "Fault queue error: fault: %d full: %d\n",
				     !!(ctrl & RISCV_IOMMU_FQCSR_FQMF),
				     !!(ctrl & RISCV_IOMMU_FQCSR_FWOF));
	}

	/* Clear fault interrupt pending. */
	riscv_iommu_writel(iommu, RISCV_IOMMU_REG_IPSR, RISCV_IOMMU_IPSR_FIP);

	/* Report fault events. */
	do {
		cnt = riscv_iommu_queue_consume(iommu, q, &idx);
		if (!cnt)
			break;
		for (len = 0; len < cnt; idx++, len++)
			riscv_iommu_fault_report(iommu, &events[idx]);
		riscv_iommu_queue_release(iommu, q, cnt);
	} while (1);

	return IRQ_HANDLED;
}

/*
 * Page request queue, chapter 3.3
 */

/*
 * Register device for IOMMU tracking.
 */
static void riscv_iommu_add_device(struct riscv_iommu_device *iommu, struct device *dev)
{
	struct riscv_iommu_endpoint *ep, *rb_ep;
	struct rb_node **new_node, *parent_node = NULL;

	mutex_lock(&iommu->eps_mutex);

	ep = dev_iommu_priv_get(dev);

	new_node = &(iommu->eps.rb_node);
	while (*new_node) {
		rb_ep = rb_entry(*new_node, struct riscv_iommu_endpoint, node);
		parent_node = *new_node;
		if (rb_ep->devid > ep->devid) {
			new_node = &((*new_node)->rb_left);
		} else if (rb_ep->devid < ep->devid) {
			new_node = &((*new_node)->rb_right);
		} else {
			dev_warn(dev, "device %u already in the tree\n", ep->devid);
			break;
		}
	}

	rb_link_node(&ep->node, parent_node, new_node);
	rb_insert_color(&ep->node, &iommu->eps);

	mutex_unlock(&iommu->eps_mutex);
}

/*
 * Get device reference based on device identifier (requester id).
 * Decrement reference count with put_device() call.
 */
static struct device *riscv_iommu_get_device(struct riscv_iommu_device *iommu,
					     unsigned devid)
{
	struct rb_node *node;
	struct riscv_iommu_endpoint *ep;
	struct device *dev = NULL;

	mutex_lock(&iommu->eps_mutex);

	node = iommu->eps.rb_node;
	while (node && !dev) {
		ep = rb_entry(node, struct riscv_iommu_endpoint, node);
		if (ep->devid < devid)
			node = node->rb_right;
		else if (ep->devid > devid)
			node = node->rb_left;
		else
			dev = get_device(ep->dev);
	}

	mutex_unlock(&iommu->eps_mutex);

	return dev;
}

static int riscv_iommu_ats_prgr(struct device *dev, struct iommu_page_response *msg)
{
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);
	struct riscv_iommu_command cmd;
	u8 resp_code;
	unsigned long payload;

	switch (msg->code) {
	case IOMMU_PAGE_RESP_SUCCESS:
		resp_code = 0b0000;
		break;
	case IOMMU_PAGE_RESP_INVALID:
		resp_code = 0b0001;
		break;
	case IOMMU_PAGE_RESP_FAILURE:
		resp_code = 0b1111;
		break;
	}
	payload = riscv_iommu_ats_prgr_payload(ep->devid, resp_code, msg->grpid);

	/* ATS Page Request Group Response */
	riscv_iommu_cmd_ats_prgr(&cmd);
	riscv_iommu_cmd_ats_set_dseg(&cmd, ep->domid);
	riscv_iommu_cmd_ats_set_rid(&cmd, ep->devid);
	if (msg->flags & IOMMU_PAGE_RESP_PASID_VALID)
		riscv_iommu_cmd_ats_set_pid(&cmd, msg->pasid);
	riscv_iommu_cmd_ats_set_payload(&cmd, payload);
	riscv_iommu_post(ep->iommu, &cmd);

	return 0;
}

static void riscv_iommu_page_request(struct riscv_iommu_device *iommu,
				     struct riscv_iommu_pq_record *req)
{
	struct iommu_fault_event event = { 0 };
	struct iommu_fault_page_request *prm = &event.fault.prm;
	int ret;
	struct device *dev;
	unsigned devid = FIELD_GET(RISCV_IOMMU_PREQ_HDR_DID, req->hdr);

	/* Ignore PGR Stop marker. */
	if ((req->payload & RISCV_IOMMU_PREQ_PAYLOAD_M) == RISCV_IOMMU_PREQ_PAYLOAD_L)
		return;

	dev = riscv_iommu_get_device(iommu, devid);
	if (!dev) {
		/* TODO: Handle invalid page request */
		return;
	}

	event.fault.type = IOMMU_FAULT_PAGE_REQ;

	if (req->payload & RISCV_IOMMU_PREQ_PAYLOAD_L)
		prm->flags |= IOMMU_FAULT_PAGE_REQUEST_LAST_PAGE;
	if (req->payload & RISCV_IOMMU_PREQ_PAYLOAD_W)
		prm->perm |= IOMMU_FAULT_PERM_WRITE;
	if (req->payload & RISCV_IOMMU_PREQ_PAYLOAD_R)
		prm->perm |= IOMMU_FAULT_PERM_READ;

	prm->grpid = FIELD_GET(RISCV_IOMMU_PREQ_PRG_INDEX, req->payload);
	prm->addr = FIELD_GET(RISCV_IOMMU_PREQ_UADDR, req->payload) << PAGE_SHIFT;

	if (req->hdr & RISCV_IOMMU_PREQ_HDR_PV) {
		prm->flags |= IOMMU_FAULT_PAGE_REQUEST_PASID_VALID;
		/* TODO: where to find this bit */
		prm->flags |= IOMMU_FAULT_PAGE_RESPONSE_NEEDS_PASID;
		prm->pasid = FIELD_GET(RISCV_IOMMU_PREQ_HDR_PID, req->hdr);
	}

	ret = iommu_report_device_fault(dev, &event);
	if (ret) {
		struct iommu_page_response resp = {
			.grpid = prm->grpid,
			.code = IOMMU_PAGE_RESP_FAILURE,
		};
		if (prm->flags & IOMMU_FAULT_PAGE_RESPONSE_NEEDS_PASID) {
			resp.flags |= IOMMU_PAGE_RESP_PASID_VALID;
			resp.pasid = prm->pasid;
		}
		riscv_iommu_ats_prgr(dev, &resp);
	}

	put_device(dev);
}

static int riscv_iommu_page_response(struct device *dev,
				     struct iommu_fault_event *evt,
				     struct iommu_page_response *msg)
{
	return riscv_iommu_ats_prgr(dev, msg);
}

/* Page request interface queue primary interrupt handler */
static irqreturn_t riscv_iommu_priq_irq_check(int irq, void *data)
{
	struct riscv_iommu_queue *q = (struct riscv_iommu_queue *)data;
	struct riscv_iommu_device *iommu =
	    container_of(q, struct riscv_iommu_device, priq);
	u32 ipsr = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_IPSR);
	if (ipsr & RISCV_IOMMU_IPSR_PIP)
		return IRQ_WAKE_THREAD;
	return IRQ_NONE;
}

/* Page request interface queue interrupt hanlder thread function */
static irqreturn_t riscv_iommu_priq_process(int irq, void *data)
{
	struct riscv_iommu_queue *q = (struct riscv_iommu_queue *)data;
	struct riscv_iommu_device *iommu;
	struct riscv_iommu_pq_record *requests;
	unsigned cnt, len, idx, ctrl;

	iommu = container_of(q, struct riscv_iommu_device, priq);
	requests = (struct riscv_iommu_pq_record *)q->base;

	/* Error reporting, clear error reports if any. */
	ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_PQCSR);
	if (ctrl & (RISCV_IOMMU_PQCSR_PQMF | RISCV_IOMMU_PQCSR_PQOF)) {
		riscv_iommu_queue_ctrl(iommu, &iommu->priq, ctrl);
		dev_warn_ratelimited(iommu->dev,
				     "Page request queue error: fault: %d full: %d\n",
				     !!(ctrl & RISCV_IOMMU_PQCSR_PQMF),
				     !!(ctrl & RISCV_IOMMU_PQCSR_PQOF));
	}

	/* Clear page request interrupt pending. */
	riscv_iommu_writel(iommu, RISCV_IOMMU_REG_IPSR, RISCV_IOMMU_IPSR_PIP);

	/* Process page requests. */
	do {
		cnt = riscv_iommu_queue_consume(iommu, q, &idx);
		if (!cnt)
			break;
		for (len = 0; len < cnt; idx++, len++)
			riscv_iommu_page_request(iommu, &requests[idx]);
		riscv_iommu_queue_release(iommu, q, cnt);
	} while (1);

	return IRQ_HANDLED;
}

/*
 * Endpoint management
 */

static int riscv_iommu_enable_ir(struct riscv_iommu_endpoint *ep)
{
	struct riscv_iommu_device *iommu = ep->iommu;
	struct iommu_resv_region *entry;
	struct irq_domain *msi_domain;
	u64 val;
	int i;

	/* Initialize MSI remapping */
	if (!ep->dc || !(iommu->cap & RISCV_IOMMU_CAP_MSI_FLAT))
		return 0;

	ep->msi_root = (struct riscv_iommu_msi_pte *)get_zeroed_page(GFP_KERNEL);
	if (!ep->msi_root)
		return -ENOMEM;

	for (i = 0; i < 256; i++) {
		ep->msi_root[i].pte = RISCV_IOMMU_MSI_PTE_V |
		    FIELD_PREP(RISCV_IOMMU_MSI_PTE_M, 3) |
		    phys_to_ppn(RISCV_IMSIC_BASE + i * PAGE_SIZE);
	}

	// TODO: get from irq_domain data.
	entry = iommu_alloc_resv_region(RISCV_IMSIC_BASE, PAGE_SIZE * 256, 0,
					IOMMU_RESV_SW_MSI, GFP_KERNEL);
	if (entry)
		list_add_tail(&entry->list, &ep->regions);

	val = virt_to_pfn(ep->msi_root) |
	    FIELD_PREP(RISCV_IOMMU_DC_MSIPTP_MODE, RISCV_IOMMU_DC_MSIPTP_MODE_FLAT);
	ep->dc->msiptp = cpu_to_le64(val);
	/* Single page of MSIPTP, 256 IMSIC files */
	ep->dc->msi_addr_mask = cpu_to_le64(255);
	ep->dc->msi_addr_pattern = cpu_to_le64(RISCV_IMSIC_BASE >> 12);
	wmb();

	// set msi domain for the device as isolated. hack.
	msi_domain = dev_get_msi_domain(ep->dev);
	if (msi_domain) {
		msi_domain->flags |= IRQ_DOMAIN_FLAG_ISOLATED_MSI;
	}

	dev_dbg(ep->dev, "RV-IR enabled\n");

	ep->ir_enabled = true;

	return 0;
}

static void riscv_iommu_disable_ir(struct riscv_iommu_endpoint *ep)
{
	if (!ep->ir_enabled)
		return;

	ep->dc->msi_addr_pattern = 0ULL;
	ep->dc->msi_addr_mask = 0ULL;
	ep->dc->msiptp = 0ULL;
	wmb();

	dev_dbg(ep->dev, "RV-IR disabled\n");

	free_pages((unsigned long)ep->msi_root, 0);
	ep->msi_root = NULL;
	ep->ir_enabled = false;
}

/* Endpoint features/capabilities */
static void riscv_iommu_disable_ep(struct riscv_iommu_endpoint *ep)
{
	struct pci_dev *pdev;

	if (!dev_is_pci(ep->dev))
		return;

	pdev = to_pci_dev(ep->dev);

	if (ep->pasid_enabled) {
		pci_disable_ats(pdev);
		pci_disable_pri(pdev);
		pci_disable_pasid(pdev);
		ep->pasid_enabled = false;
	}
}

static void riscv_iommu_enable_ep(struct riscv_iommu_endpoint *ep)
{
	int rc, feat, num;
	struct pci_dev *pdev;
	struct device *dev = ep->dev;

	if (!dev_is_pci(dev))
		return;
	if (!ep->iommu->iommu.max_pasids)
		return;

	pdev = to_pci_dev(dev);

	/* TODO: Check IOMMU Capabilities before enabling ATS/PRI/PASID for devices */

	if (!pci_ats_supported(pdev))
		return;

	if (!pci_pri_supported(pdev))
		return;

	feat = pci_pasid_features(pdev);
	if (feat < 0)
		return;

	num = pci_max_pasids(pdev);
	if (!num) {
		dev_warn(dev, "Can't enable PASID (num: %d)\n", num);
		return;
	}

	rc = pci_enable_pasid(pdev, feat);
	if (rc) {
		dev_warn(dev, "Can't enable PASID (rc: %d)\n", rc);
		return;
	}

	rc = pci_reset_pri(pdev);
	if (rc) {
		dev_warn(dev, "Can't reset PRI (rc: %d)\n", rc);
		pci_disable_pasid(pdev);
		return;
	}

	/* TODO: Get supported PRI queue length, hard-code to 32 entries */
	rc = pci_enable_pri(pdev, 32);
	if (rc) {
		dev_warn(dev, "Can't enable PRI (rc: %d)\n", rc);
		pci_disable_pasid(pdev);
		return;
	}

	rc = pci_enable_ats(pdev, PAGE_SHIFT);
	if (rc) {
		dev_warn(dev, "Can't enable ATS (rc: %d)\n", rc);
		pci_disable_pri(pdev);
		pci_disable_pasid(pdev);
		return;
	}

	ep->pasid_enabled = true;
	ep->pasid_feat = feat;
	ep->pasid_bits = ilog2(min_t(unsigned int, num,
					 ep->iommu->iommu.max_pasids));

	dev_dbg(ep->dev, "PASID/ATS support enabled, %d bits\n", ep->pasid_bits);
}

static int riscv_iommu_enable_sva(struct device *dev)
{
	int ret;
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);

	if (!ep || !ep->iommu || !ep->iommu->pq_work)
		return -EINVAL;

	if (!ep->pasid_enabled)
		return -ENODEV;

	ret = iopf_queue_add_device(ep->iommu->pq_work, dev);
	if (ret)
		return ret;

	return iommu_register_device_fault_handler(dev, iommu_queue_iopf, dev);
}

static int riscv_iommu_disable_sva(struct device *dev)
{
	int ret;
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);

	ret = iommu_unregister_device_fault_handler(dev);
	if (!ret)
		ret = iopf_queue_remove_device(ep->iommu->pq_work, dev);

	return ret;
}

static int riscv_iommu_enable_iopf(struct device *dev)
{
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);

	if (ep && ep->pasid_enabled)
		return 0;

	return -EINVAL;
}

static int riscv_iommu_dev_enable_feat(struct device *dev, enum iommu_dev_features feat)
{
	switch (feat) {
	case IOMMU_DEV_FEAT_IOPF:
		return riscv_iommu_enable_iopf(dev);

	case IOMMU_DEV_FEAT_SVA:
		return riscv_iommu_enable_sva(dev);

	default:
		return -ENODEV;
	}
}

static int riscv_iommu_dev_disable_feat(struct device *dev, enum iommu_dev_features feat)
{
	switch (feat) {
	case IOMMU_DEV_FEAT_IOPF:
		return 0;

	case IOMMU_DEV_FEAT_SVA:
		return riscv_iommu_disable_sva(dev);

	default:
		return -ENODEV;
	}
}

static int riscv_iommu_of_xlate(struct device *dev, struct of_phandle_args *args)
{
	return iommu_fwspec_add_ids(dev, args->args, 1);
}

static bool riscv_iommu_capable(struct device *dev, enum iommu_cap cap)
{
	switch (cap) {
	case IOMMU_CAP_CACHE_COHERENCY:
	case IOMMU_CAP_PRE_BOOT_PROTECTION:
		return true;

	default:
		break;
	}

	return false;
}

/* TODO: implement proper device context management, e.g. teardown flow */

/* Lookup or initialize device directory info structure. */
static struct riscv_iommu_dc *riscv_iommu_get_dc(struct riscv_iommu_device *iommu,
						 unsigned devid)
{
	const bool base_format = !(iommu->cap & RISCV_IOMMU_CAP_MSI_FLAT);
	unsigned depth = iommu->ddt_mode - RISCV_IOMMU_DDTP_MODE_1LVL;
	u8 ddi_bits[3] = { 0 };
	u64 *ddtp = NULL, ddt;

	if (iommu->ddt_mode == RISCV_IOMMU_DDTP_MODE_OFF ||
	    iommu->ddt_mode == RISCV_IOMMU_DDTP_MODE_BARE)
		return NULL;

	/* Make sure the mode is valid */
	if (iommu->ddt_mode > RISCV_IOMMU_DDTP_MODE_MAX)
		return NULL;

	/*
	 * Device id partitioning for base format:
	 * DDI[0]: bits 0 - 6   (1st level) (7 bits)
	 * DDI[1]: bits 7 - 15  (2nd level) (9 bits)
	 * DDI[2]: bits 16 - 23 (3rd level) (8 bits)
	 *
	 * For extended format:
	 * DDI[0]: bits 0 - 5   (1st level) (6 bits)
	 * DDI[1]: bits 6 - 14  (2nd level) (9 bits)
	 * DDI[2]: bits 15 - 23 (3rd level) (9 bits)
	 */
	if (base_format) {
		ddi_bits[0] = 7;
		ddi_bits[1] = 7 + 9;
		ddi_bits[2] = 7 + 9 + 8;
	} else {
		ddi_bits[0] = 6;
		ddi_bits[1] = 6 + 9;
		ddi_bits[2] = 6 + 9 + 9;
	}

	/* Make sure device id is within range */
	if (devid >= (1 << ddi_bits[depth]))
		return NULL;

	/* Get to the level of the non-leaf node that holds the device context */
	for (ddtp = (u64 *) iommu->ddtp; depth-- > 0;) {
		const int split = ddi_bits[depth];
		/*
		 * Each non-leaf node is 64bits wide and on each level
		 * nodes are indexed by DDI[depth].
		 */
		ddtp += (devid >> split) & 0x1FF;

 retry:
		/*
		 * Check if this node has been populated and if not
		 * allocate a new level and populate it.
		 */
		ddt = READ_ONCE(*ddtp);
		if (ddt & RISCV_IOMMU_DDTE_VALID) {
			ddtp = __va(ppn_to_phys(ddt));
		} else {
			u64 old, new = get_zeroed_page(GFP_KERNEL);
			if (!new)
				return NULL;

			old = cmpxchg64_relaxed(ddtp, ddt,
						phys_to_ppn(__pa(new)) |
						RISCV_IOMMU_DDTE_VALID);

			if (old != ddt) {
				free_page(new);
				goto retry;
			}

			ddtp = (u64 *) new;
		}
	}

	/*
	 * Grab the node that matches DDI[depth], note that when using base
	 * format the device context is 4 * 64bits, and the extended format
	 * is 8 * 64bits, hence the (3 - base_format) below.
	 */
	ddtp += (devid & ((64 << base_format) - 1)) << (3 - base_format);
	return (struct riscv_iommu_dc *)ddtp;
}

static struct iommu_device *riscv_iommu_probe_device(struct device *dev)
{
	struct riscv_iommu_device *iommu;
	struct riscv_iommu_endpoint *ep;
	struct iommu_fwspec *fwspec;

	fwspec = dev_iommu_fwspec_get(dev);
	if (!fwspec || fwspec->ops != &riscv_iommu_ops ||
	    !fwspec->iommu_fwnode || !fwspec->iommu_fwnode->dev)
		return ERR_PTR(-ENODEV);

	iommu = dev_get_drvdata(fwspec->iommu_fwnode->dev);
	if (!iommu)
		return ERR_PTR(-ENODEV);

	if (dev_iommu_priv_get(dev))
		return &iommu->iommu;

	ep = kzalloc(sizeof(*ep), GFP_KERNEL);
	if (!ep)
		return ERR_PTR(-ENOMEM);

	mutex_init(&ep->lock);
	INIT_LIST_HEAD(&ep->regions);
	INIT_LIST_HEAD(&ep->domains);

	if (dev_is_pci(dev)) {
		ep->devid = pci_dev_id(to_pci_dev(dev));
		ep->domid = pci_domain_nr(to_pci_dev(dev)->bus);
	} else {
		/* TODO: Make this generic, for now hardcode domain id to 0 */
		ep->devid = fwspec->ids[0];
		ep->domid = 0;
	}

	ep->iommu = iommu;
	ep->dev = dev;

	/* Initial DC pointer can be NULL if IOMMU is configured in OFF or BARE mode */
	ep->dc = riscv_iommu_get_dc(iommu, ep->devid);

	dev_dbg(iommu->dev, "adding device to iommu with devid %i in domain %i\n",
		ep->devid, ep->domid);

	dev_iommu_priv_set(dev, ep);
	riscv_iommu_add_device(iommu, dev);
	riscv_iommu_enable_ep(ep);
	riscv_iommu_enable_ir(ep);

	return &iommu->iommu;
}

static void riscv_iommu_probe_finalize(struct device *dev)
{
	set_dma_ops(dev, NULL);
	iommu_setup_dma_ops(dev, 0, U64_MAX);
}

static int riscv_iommu_detach_endpoint(struct riscv_iommu_endpoint *ep)
{
	struct riscv_iommu_domain *old;
	int ret = 0;

	mutex_lock(&riscv_iommu_domain_mutex);
	old = ep->domain;
	if (old)
		mutex_lock(&old->lock);
	mutex_lock(&ep->lock);
	if (ep->dc) {
		ep->dc->tc = 0;
		wmb();
		if (!riscv_iommu_iodir_inv_devid(ep->iommu, ep->devid)) {
			ret = -EIO;
			goto unlock;
		}
	}
	if (old)
		old->retired_epoch = READ_ONCE(ep->iommu->research_epoch);
	list_del_init(&ep->domains);
	ep->domain = NULL;
unlock:
	mutex_unlock(&ep->lock);
	if (old)
		mutex_unlock(&old->lock);
	mutex_unlock(&riscv_iommu_domain_mutex);
	return ret;
}

static void riscv_iommu_release_device(struct device *dev)
{
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);
	struct riscv_iommu_device *iommu = ep->iommu;

	dev_dbg(dev, "device with devid %i released\n", ep->devid);

	if (ep->domain) {
		if (WARN_ON(riscv_iommu_detach_endpoint(ep)))
			return;
	}

	if (ep->dc) {
		// this should be already done by domain detach.
		ep->dc->tc = 0ULL;
		wmb();
		ep->dc->fsc = 0ULL;
		ep->dc->iohgatp = 0ULL;
		wmb();
		riscv_iommu_iodir_inv_devid(iommu, ep->devid);
	}

	riscv_iommu_disable_ir(ep);
	riscv_iommu_disable_ep(ep);

	/* Remove endpoint from IOMMU tracking structures */
	mutex_lock(&iommu->eps_mutex);
	rb_erase(&ep->node, &iommu->eps);
	mutex_unlock(&iommu->eps_mutex);

	set_dma_ops(dev, NULL);
	dev_iommu_priv_set(dev, NULL);

	kfree(ep);
}

static struct iommu_group *riscv_iommu_device_group(struct device *dev)
{
	if (dev_is_pci(dev))
		return pci_device_group(dev);
	return generic_device_group(dev);
}

static void riscv_iommu_get_resv_regions(struct device *dev, struct list_head *head)
{
	struct iommu_resv_region *entry, *new_entry;
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);

	list_for_each_entry(entry, &ep->regions, list) {
		new_entry = kmemdup(entry, sizeof(*entry), GFP_KERNEL);
		if (new_entry)
			list_add_tail(&new_entry->list, head);
	}

	iommu_dma_get_resv_regions(dev, head);
}

/*
 * Domain management
 */

static struct iommu_domain *riscv_iommu_domain_alloc(unsigned type)
{
	struct riscv_iommu_domain *domain;

	if (type != IOMMU_DOMAIN_DMA &&
	    type != IOMMU_DOMAIN_DMA_FQ &&
	    type != IOMMU_DOMAIN_UNMANAGED &&
	    type != IOMMU_DOMAIN_IDENTITY &&
	    type != IOMMU_DOMAIN_BLOCKED && type != IOMMU_DOMAIN_SVA)
		return NULL;

	domain = kzalloc(sizeof(*domain), GFP_KERNEL);
	if (!domain)
		return NULL;

	mutex_init(&domain->lock);
	INIT_LIST_HEAD(&domain->endpoints);
	domain->domain.ops = &riscv_iommu_domain_ops;
	domain->mode = RISCV_IOMMU_DC_FSC_MODE_BARE;

	return &domain->domain;
}

static void riscv_iommu_domain_free(struct iommu_domain *iommu_domain)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);
	bool reclaim_id;

	mutex_lock(&riscv_iommu_domain_mutex);
	mutex_lock(&domain->lock);
	reclaim_id = !domain->ever_attached ||
		(!domain->g_stage && !READ_ONCE(domain->iommu->research_cq_poisoned) &&
		 READ_ONCE(domain->iommu->research_epoch) > domain->retired_epoch);
	/* Never discard a root that an endpoint (or uncertain CQ) can use. */
	if (WARN_ON(!list_empty(&domain->endpoints)) ||
	    (domain->research_domain && !reclaim_id)) {
		mutex_unlock(&domain->lock);
		mutex_unlock(&riscv_iommu_domain_mutex);
		return;
	}
	mutex_unlock(&domain->lock);
	mutex_unlock(&riscv_iommu_domain_mutex);

	if (domain->mn.ops && iommu_domain->mm)
		mmu_notifier_unregister(&domain->mn, iommu_domain->mm);
	if (domain->pgtbl.cookie)
		free_io_pgtable_ops(&domain->pgtbl.ops);
	if (domain->pgd_root && !domain->pgd_borrowed)
		free_pages((unsigned long)domain->pgd_root, domain->g_stage ? 2 : 0);
	/*
	 * The old driver leaked ordinary identifiers. Do not turn that leak
	 * into unsafe reuse: a detached ordinary root can be freed under its
	 * original contract, but retain its ID lease without a later certified
	 * host invalidation. Host VMA never certifies an attached GSCID.
	 */
	if (domain->id_allocated && reclaim_id)
		ida_free(domain->g_stage ? &riscv_iommu_gscids : &riscv_iommu_pscids,
			 domain->id);
	if (domain->borrowed_mm)
		mmput(domain->borrowed_mm);
	kfree(domain);
}

static int riscv_iommu_domain_finalize(struct riscv_iommu_domain *domain,
				       struct riscv_iommu_device *iommu)
{
	struct iommu_domain_geometry *geometry = &domain->domain.geometry;
	int id;

	if (domain->iommu)
		return domain->iommu == iommu ? 0 : -EXDEV;
	geometry->aperture_start = 0;
	geometry->aperture_end = DMA_BIT_MASK(VA_BITS - 1);
	geometry->force_aperture = true;
	if (domain->domain.type == IOMMU_DOMAIN_IDENTITY ||
	    domain->domain.type == IOMMU_DOMAIN_BLOCKED) {
		domain->iommu = iommu;
		return 0;
	}
	if (domain->pgd_borrowed &&
	    ((satp_mode >> 60) != RISCV_IOMMU_DC_FSC_IOSATP_MODE_SV39 ||
	     !(iommu->cap & RISCV_IOMMU_CAP_S_SV39) || domain->g_stage))
		return -EOPNOTSUPP;

	id = domain->g_stage ? ida_alloc_range(&riscv_iommu_gscids, 1,
						  GENMASK(15, 0), GFP_KERNEL) :
		ida_alloc_range(&riscv_iommu_pscids, RISCV_IOMMU_DOMAIN_PSCID_MIN,
				RISCV_IOMMU_DOMAIN_PSCID_MAX, GFP_KERNEL);
	if (id < 0)
		return id;
	domain->id = id;
	domain->id_allocated = true;
	domain->mode = satp_mode >> 60;
	if (!domain->pgd_borrowed) {
		domain->pgd_root = (pgd_t *)__get_free_pages(GFP_KERNEL | __GFP_ZERO,
							 domain->g_stage ? 2 : 0);
		if (!domain->pgd_root)
			goto fail_id;
		if (!alloc_io_pgtable_ops(RISCV_IOMMU, &domain->pgtbl.cfg, domain))
			goto fail_root;
	}
	/* Publish initialized state only after all allocations succeeded. */
	domain->iommu = iommu;
	return 0;

fail_root:
	free_pages((unsigned long)domain->pgd_root, domain->g_stage ? 2 : 0);
	domain->pgd_root = NULL;
fail_id:
	ida_free(domain->g_stage ? &riscv_iommu_gscids : &riscv_iommu_pscids, id);
	domain->id_allocated = false;
	domain->id = 0;
	domain->mode = RISCV_IOMMU_DC_FSC_MODE_BARE;
	return -ENOMEM;
}

static u64 riscv_iommu_domain_atp(struct riscv_iommu_domain *domain)
{
	u64 atp = FIELD_PREP(RISCV_IOMMU_DC_FSC_MODE, domain->mode);
	if (domain->mode != RISCV_IOMMU_DC_FSC_MODE_BARE)
		atp |= FIELD_PREP(RISCV_IOMMU_DC_FSC_PPN, virt_to_pfn(domain->pgd_root));
	if (domain->g_stage)
		atp |= FIELD_PREP(RISCV_IOMMU_DC_IOHGATP_GSCID, domain->id);
	return atp;
}

static int riscv_iommu_attach_dev(struct iommu_domain *iommu_domain, struct device *dev)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);
	struct riscv_iommu_domain *old;
	struct riscv_iommu_dc saved, *dc;
	int ret;
	u64 val;

	if (!ep || !ep->dc)
		return -ENODEV;
	dc = ep->dc;
	mutex_lock(&riscv_iommu_domain_mutex);
	old = ep->domain;
	/* All transition paths share this outer lock; old/new never race. */
	if (old && old != domain)
		mutex_lock(&old->lock);
	mutex_lock_nested(&domain->lock, SINGLE_DEPTH_NESTING);
	mutex_lock(&ep->lock);
	ret = 0;
	if (old == domain)
		goto unlock;
	if (READ_ONCE(ep->iommu->research_cq_poisoned)) {
		ret = -EIO;
		goto unlock;
	}
	if (domain->research_domain &&
	    (ep->pasid_enabled || (ep->devid != 10 && ep->devid != 11))) {
		ret = -EOPNOTSUPP;
		goto unlock;
	}
	ret = riscv_iommu_domain_finalize(domain, ep->iommu);
	if (ret)
		goto unlock;

	saved = *dc;
	/* Invalidate before replacing any context fields. Caller quiesces DMA. */
	dc->tc = 0;
	wmb();
	if (domain->g_stage) {
		dc->iohgatp = cpu_to_le64(riscv_iommu_domain_atp(domain));
		dc->fsc = 0;
		dc->ta = 0;
	} else {
		dc->iohgatp = 0; /* no stale guest-stage root on a host transition */
		dc->ta = cpu_to_le64(FIELD_PREP(RISCV_IOMMU_DC_TA_PSCID, domain->id));
		dc->fsc = cpu_to_le64(riscv_iommu_domain_atp(domain));
	}
	wmb();
	val = domain->domain.type == IOMMU_DOMAIN_BLOCKED ? 0 : RISCV_IOMMU_DC_TC_V;
	if (ep->pasid_enabled)
		val |= RISCV_IOMMU_DC_TC_EN_ATS | RISCV_IOMMU_DC_TC_EN_PRI | BIT_ULL(32);
	if (!domain->pgd_borrowed && (ep->iommu->cap & RISCV_IOMMU_CAP_AMO))
		val |= RISCV_IOMMU_DC_TC_GADE | RISCV_IOMMU_DC_TC_SADE;
	dc->tc = cpu_to_le64(val);
	wmb();
	if (!riscv_iommu_iodir_inv_devid(ep->iommu, ep->devid)) {
		/* No list change until the invalidation was actually queued. */
		dc->tc = 0;
		wmb();
		dc->ta = saved.ta;
		dc->fsc = saved.fsc;
		dc->iohgatp = saved.iohgatp;
		wmb();
		dc->tc = saved.tc;
		wmb();
		ret = -EIO;
		goto unlock;
	}
	if (old) {
		list_del_init(&ep->domains);
		old->retired_epoch = READ_ONCE(ep->iommu->research_epoch);
	}
	ep->domain = domain;
	list_add_tail(&ep->domains, &domain->endpoints);
	domain->ever_attached = true;
	domain->retired_epoch = READ_ONCE(ep->iommu->research_epoch);
unlock:
	mutex_unlock(&ep->lock);
	mutex_unlock(&domain->lock);
	if (old && old != domain)
		mutex_unlock(&old->lock);
	mutex_unlock(&riscv_iommu_domain_mutex);
	return ret;
}

static int riscv_iommu_set_dev_pasid(struct iommu_domain *iommu_domain,
				     struct device *dev, ioasid_t pasid)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);
	struct riscv_iommu_dc *dc = ep->dc;
	struct riscv_iommu_pc *pc = ep->pc;
	struct mm_struct *mm;

	if (!iommu_domain || !iommu_domain->mm)
		return -EINVAL;
	if (pasid >= RISCV_IOMMU_DOMAIN_PSCID_MIN)
		return -EOPNOTSUPP;
	if (!ep || !ep->pasid_enabled || !dc)
		return -ENODEV;
	if (!pc)
		pc = (struct riscv_iommu_pc *)get_zeroed_page(GFP_KERNEL);
	if (!pc)
		return -ENOMEM;

	/* register mm notifier */
	mm = iommu_domain->mm;
	domain->pscid = pasid;
	domain->iommu = ep->iommu;
	domain->mn.ops = &riscv_iommu_mmuops;

	if (mmu_notifier_register(&domain->mn, mm))
		return -ENODEV;

	mutex_lock(&domain->lock);

	/* Use PASID for PSCID tag */
	pc[pasid].ta = cpu_to_le64(FIELD_PREP(RISCV_IOMMU_PC_TA_PSCID, pasid) |
				   RISCV_IOMMU_PC_TA_V);

	/* TODO: get SXL value for the process, use 32 bit or SATP mode */
	pc[pasid].fsc = cpu_to_le64(virt_to_pfn(mm->pgd) | satp_mode);

	/* update DC with sva->mm */
	if (!(ep->dc->tc & RISCV_IOMMU_DC_TC_PDTV)) {
		/* migrate to PD, domain mappings moved to PASID:0 */
		pc[0].ta = dc->ta;
		pc[0].fsc = dc->fsc;
		dc->fsc = cpu_to_le64(virt_to_pfn(pc) |
		    FIELD_PREP(RISCV_IOMMU_DC_FSC_MODE, RISCV_IOMMU_DC_FSC_PDTP_MODE_PD8));
		dc->tc |= cpu_to_le64(RISCV_IOMMU_DC_TC_PDTV | RISCV_IOMMU_DC_TC_DPE);
		ep->pc = pc;
		wmb();

		/* TODO: transition to PD steps */
		riscv_iommu_iodir_inv_devid(ep->iommu, ep->devid);
	} else {
		wmb();
		riscv_iommu_iodir_inv_pasid(ep->iommu, ep->devid, pasid);
	}

	mutex_unlock(&domain->lock);
	riscv_iommu_iofence_sync(ep->iommu);

	return 0;
}

static void riscv_iommu_remove_dev_pasid(struct device *dev, ioasid_t pasid)
{
	struct riscv_iommu_endpoint *ep = dev_iommu_priv_get(dev);
	struct riscv_iommu_command cmd;
	unsigned long payload = riscv_iommu_ats_inval_all_payload(false);

	/* remove SVA iommu-domain */

	/* invalidate TA.V */
	ep->pc[pasid].ta = 0;
	wmb();

	/* 1. invalidate PDT entry */
	riscv_iommu_iodir_inv_pasid(ep->iommu, ep->devid, pasid);

	/* 2. invalidate all matching IOATC entries */
	riscv_iommu_cmd_inval_vma(&cmd);
	riscv_iommu_cmd_inval_set_gscid(&cmd, 0);
	riscv_iommu_cmd_inval_set_pscid(&cmd, pasid);
	riscv_iommu_post(ep->iommu, &cmd);

	/* 3. Wait IOATC flush to happen */
	riscv_iommu_iofence_sync(ep->iommu);

	/* 4. ATS invalidation */
	riscv_iommu_cmd_ats_inval(&cmd);
	riscv_iommu_cmd_ats_set_dseg(&cmd, ep->domid);
	riscv_iommu_cmd_ats_set_rid(&cmd, ep->devid);
	riscv_iommu_cmd_ats_set_pid(&cmd, pasid);
	riscv_iommu_cmd_ats_set_payload(&cmd, payload);
	riscv_iommu_post(ep->iommu, &cmd);

	/* 5. Wait DevATC flush to happen */
	riscv_iommu_iofence_sync(ep->iommu);
}

/* mark domain as second-stage translation */
static int riscv_iommu_enable_nesting(struct iommu_domain *iommu_domain)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);

	mutex_lock(&domain->lock);
	/* An initialized PSCID/root cannot be reinterpreted as a GSCID/root. */
	if (domain->iommu || domain->research_domain || domain->pgd_borrowed) {
		mutex_unlock(&domain->lock);
		return -EOPNOTSUPP;
	}
	if (list_empty(&domain->endpoints))
		domain->g_stage = true;
	mutex_unlock(&domain->lock);

	return domain->g_stage ? 0 : -EBUSY;
}

static void riscv_iommu_flush_iotlb_range(struct iommu_domain *iommu_domain,
					  unsigned long *start, unsigned long *end,
					  size_t *pgsize)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);
	struct riscv_iommu_command cmd;
	struct riscv_iommu_endpoint *endpoint;
	// unsigned long iova;
	unsigned long payload;

	if (domain->mode == RISCV_IOMMU_DC_FSC_MODE_BARE)
		return;

	/* Domain not attached to an IOMMU! */
	BUG_ON(!domain->iommu);

	if (start && end) {
		payload = riscv_iommu_ats_inval_payload(*start, *end, true);
	} else {
		payload = riscv_iommu_ats_inval_all_payload(true);
	}

	if (domain->g_stage) {
		riscv_iommu_cmd_inval_gvma(&cmd);
		riscv_iommu_cmd_inval_set_gscid(&cmd, domain->id);
	} else {
		riscv_iommu_cmd_inval_vma(&cmd);
		// riscv_iommu_cmd_inval_set_pscid(&cmd, domain->id);
	}

	// if (start && end && pgsize) {
	// 	/* Cover only the range that is needed */
	// 	for (iova = *start; iova <= *end; iova += *pgsize) {
	// 		printk("Sending IOTINVAL with ADDR");
	// 		riscv_iommu_cmd_inval_set_addr(&cmd, iova);
	// 		riscv_iommu_post(domain->iommu, &cmd);
	// 	}
	// } else {
		riscv_iommu_post(domain->iommu, &cmd);
	// }
	riscv_iommu_iofence_sync(domain->iommu);

	/* ATS invalidation for every device and for every translation */
	mutex_lock(&domain->lock);
	list_for_each_entry(endpoint, &domain->endpoints, domains) {
		if (!endpoint->pasid_enabled)
			continue;

		riscv_iommu_cmd_ats_inval(&cmd);
		riscv_iommu_cmd_ats_set_dseg(&cmd, endpoint->domid);
		riscv_iommu_cmd_ats_set_rid(&cmd, endpoint->devid);
		riscv_iommu_cmd_ats_set_pid(&cmd, domain->pscid);
		riscv_iommu_cmd_ats_set_payload(&cmd, payload);
		riscv_iommu_post(domain->iommu, &cmd);
	}
	mutex_unlock(&domain->lock);
	riscv_iommu_iofence_sync(domain->iommu);
}

static void riscv_iommu_flush_iotlb_all(struct iommu_domain *iommu_domain)
{
	riscv_iommu_flush_iotlb_range(iommu_domain, NULL, NULL, NULL);
}

static void riscv_iommu_iotlb_sync(struct iommu_domain *iommu_domain,
				   struct iommu_iotlb_gather *gather)
{
	riscv_iommu_flush_iotlb_range(iommu_domain, &gather->start, &gather->end,
				      &gather->pgsize);
}

static void riscv_iommu_iotlb_sync_map(struct iommu_domain *iommu_domain,
				       unsigned long iova, size_t size)
{
	unsigned long end = iova + size - 1;
	/*
	 * Given we don't know the page size used by this range, we assume the
	 * smallest page size to ensure all possible entries are flushed from
	 * the IOATC.
	 */
	size_t pgsize = PAGE_SIZE;
	riscv_iommu_flush_iotlb_range(iommu_domain, &iova, &end, &pgsize);
}

static int riscv_iommu_map_pages(struct iommu_domain *iommu_domain,
				 unsigned long iova, phys_addr_t phys,
				 size_t pgsize, size_t pgcount, int prot,
				 gfp_t gfp, size_t *mapped)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);

	pr_debug("Mapping IOVA %llx to SPA %llx\n", (unsigned long long)iova, phys);

	if (domain->pgd_borrowed)
		return -EPERM;
	if (!domain->pgtbl.ops.map_pages)
		return -ENODEV;

	return domain->pgtbl.ops.map_pages(&domain->pgtbl.ops, iova, phys,
					   pgsize, pgcount, prot, gfp, mapped);
}

static size_t riscv_iommu_unmap_pages(struct iommu_domain *iommu_domain,
				      unsigned long iova, size_t pgsize,
				      size_t pgcount, struct iommu_iotlb_gather *gather)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);

	if (domain->pgd_borrowed)
		return 0;
	if (!domain->pgtbl.ops.unmap_pages)
		return 0;

	return domain->pgtbl.ops.unmap_pages(&domain->pgtbl.ops, iova, pgsize,
					     pgcount, gather);
}

static phys_addr_t riscv_iommu_iova_to_phys(struct iommu_domain *iommu_domain,
					    dma_addr_t iova)
{
	struct riscv_iommu_domain *domain = iommu_domain_to_riscv(iommu_domain);

	if (!domain->pgtbl.ops.iova_to_phys)
		return 0;

	return domain->pgtbl.ops.iova_to_phys(&domain->pgtbl.ops, iova);
}

/*
 * Translation mode setup
 */

static u64 riscv_iommu_get_ddtp(struct riscv_iommu_device *iommu)
{
	u64 ddtp;
	cycles_t end_cycles = RISCV_IOMMU_TIMEOUT + get_cycles();

	/* Wait for DDTP.BUSY to be cleared and return latest value */
	do {
		ddtp = riscv_iommu_readq(iommu, RISCV_IOMMU_REG_DDTP);
		if (!(ddtp & RISCV_IOMMU_DDTP_BUSY))
			break;
		cpu_relax();
	} while (get_cycles() < end_cycles);

	return ddtp;
}

static void riscv_iommu_ddt_cleanup(struct riscv_iommu_device *iommu)
{
	/* TODO: teardown whole device directory tree. */
	if (iommu->ddtp) {
		if (iommu->ddtp_in_iomem) {
			iounmap((void *)iommu->ddtp);
		} else
			free_page(iommu->ddtp);
		iommu->ddtp = 0;
	}
}

static int riscv_iommu_enable(struct riscv_iommu_device *iommu, unsigned requested_mode)
{
	struct device *dev = iommu->dev;
	u64 ddtp = 0;
	u64 ddtp_paddr = 0;
	unsigned mode = requested_mode;
	unsigned mode_readback = 0;

	ddtp = riscv_iommu_get_ddtp(iommu);
	if (ddtp & RISCV_IOMMU_DDTP_BUSY)
		return -EBUSY;

	/* Disallow state transtion from xLVL to xLVL. */
	// switch (FIELD_GET(RISCV_IOMMU_DDTP_MODE, ddtp)) {
	// case RISCV_IOMMU_DDTP_MODE_BARE:
	// case RISCV_IOMMU_DDTP_MODE_OFF:
	// 	break;
	// default:
	// 	if ((mode != RISCV_IOMMU_DDTP_MODE_BARE)
	// 	    && (mode != RISCV_IOMMU_DDTP_MODE_OFF))
	// 		return -EINVAL;
	// 	break;
	// }

 retry:
	switch (mode) {
	case RISCV_IOMMU_DDTP_MODE_BARE:
	case RISCV_IOMMU_DDTP_MODE_OFF:
		riscv_iommu_ddt_cleanup(iommu);
		ddtp = FIELD_PREP(RISCV_IOMMU_DDTP_MODE, mode);
		break;
	case RISCV_IOMMU_DDTP_MODE_1LVL:
	case RISCV_IOMMU_DDTP_MODE_2LVL:
	case RISCV_IOMMU_DDTP_MODE_3LVL:
		if (!iommu->ddtp) {
			/*
			 * We haven't initialized ddtp yet, since it's WARL make
			 * sure that we don't have a hardwired PPN field there
			 * that points to i/o memory instead.
			 */
			riscv_iommu_writeq(iommu, RISCV_IOMMU_REG_DDTP, 0);
			ddtp = riscv_iommu_get_ddtp(iommu);
			ddtp_paddr = ppn_to_phys(ddtp);
			if (ddtp_paddr) {
				dev_warn(dev, "ddtp at 0x%llx\n", ddtp_paddr);
				iommu->ddtp =
				    (unsigned long)ioremap(ddtp_paddr, PAGE_SIZE);
				iommu->ddtp_in_iomem = true;
			} else {
				iommu->ddtp = get_zeroed_page(GFP_KERNEL);
			}
		}
		if (!iommu->ddtp)
			return -ENOMEM;

		ddtp = FIELD_PREP(RISCV_IOMMU_DDTP_MODE, mode) |
		    phys_to_ppn(__pa(iommu->ddtp));

		break;
	default:
		return -EINVAL;
	}

	riscv_iommu_writeq(iommu, RISCV_IOMMU_REG_DDTP, ddtp);
	ddtp = riscv_iommu_get_ddtp(iommu);
	if (ddtp & RISCV_IOMMU_DDTP_BUSY) {
		dev_warn(dev, "timeout when setting ddtp (ddt mode: %i)\n", mode);
		return -EBUSY;
	}

	mode_readback = FIELD_GET(RISCV_IOMMU_DDTP_MODE, ddtp);
	dev_info(dev, "mode_readback: %i, mode: %i\n", mode_readback, mode);
	if (mode_readback != mode) {
		/*
		 * Mode field is WARL, an I/O MMU may support a subset of
		 * directory table levels in which case if we tried to set
		 * an unsupported number of levels we'll readback either
		 * a valid xLVL or off/bare. If we got off/bare, try again
		 * with a smaller xLVL.
		 */
		if (mode_readback < RISCV_IOMMU_DDTP_MODE_1LVL &&
		    mode > RISCV_IOMMU_DDTP_MODE_1LVL) {
			mode--;
			goto retry;
		}

		/*
		 * We tried all supported xLVL modes and still got off/bare instead,
		 * an I/O MMU must support at least one supported xLVL mode so something
		 * went very wrong.
		 */
		if (mode_readback < RISCV_IOMMU_DDTP_MODE_1LVL &&
		    mode == RISCV_IOMMU_DDTP_MODE_1LVL)
			goto fail;

		/*
		 * We tried setting off or bare and got something else back, something
		 * went very wrong since off/bare is always legal.
		 */
		if (mode < RISCV_IOMMU_DDTP_MODE_1LVL)
			goto fail;

		/*
		 * We tried setting an xLVL mode but got another xLVL mode that
		 * we don't support (e.g. a custom one).
		 */
		if (mode_readback > RISCV_IOMMU_DDTP_MODE_MAX)
			goto fail;

		/* We tried setting an xLVL mode but got another supported xLVL mode */
		mode = mode_readback;
	}

	if (mode != requested_mode)
		dev_warn(dev, "unsupported DDT mode requested (%i), using %i instead\n",
			 requested_mode, mode);

	iommu->ddt_mode = mode;
	dev_info(dev, "ddt_mode: %i\n", iommu->ddt_mode);
	return 0;

 fail:
	dev_err(dev, "failed to set DDT mode, tried: %i and got %i\n", mode,
		mode_readback);
	riscv_iommu_ddt_cleanup(iommu);
	return -EINVAL;
}

/*
 * Common I/O MMU driver probe/teardown
 */

static const struct iommu_domain_ops riscv_iommu_domain_ops = {
	.free = riscv_iommu_domain_free,
	.attach_dev = riscv_iommu_attach_dev,
	.set_dev_pasid = riscv_iommu_set_dev_pasid,
	.map_pages = riscv_iommu_map_pages,
	.unmap_pages = riscv_iommu_unmap_pages,
	.iova_to_phys = riscv_iommu_iova_to_phys,
	.iotlb_sync = riscv_iommu_iotlb_sync,
	.iotlb_sync_map = riscv_iommu_iotlb_sync_map,
	.flush_iotlb_all = riscv_iommu_flush_iotlb_all,
	.enable_nesting = riscv_iommu_enable_nesting,
};

static const struct iommu_ops riscv_iommu_ops = {
	.owner = THIS_MODULE,
	.pgsize_bitmap = SZ_4K | SZ_2M | SZ_512M,
	.capable = riscv_iommu_capable,
	.domain_alloc = riscv_iommu_domain_alloc,
	.probe_device = riscv_iommu_probe_device,
	.probe_finalize = riscv_iommu_probe_finalize,
	.release_device = riscv_iommu_release_device,
	.remove_dev_pasid = riscv_iommu_remove_dev_pasid,
	.device_group = riscv_iommu_device_group,
	.get_resv_regions = riscv_iommu_get_resv_regions,
	.of_xlate = riscv_iommu_of_xlate,
	.dev_enable_feat = riscv_iommu_dev_enable_feat,
	.dev_disable_feat = riscv_iommu_dev_disable_feat,
	.page_response = riscv_iommu_page_response,
	.default_domain_ops = &riscv_iommu_domain_ops,
};

struct riscv_iommu_endpoint *riscv_iommu_hpm_endpoint(struct device *dev)
{
	struct iommu_fwspec *fwspec;
	struct riscv_iommu_endpoint *ep;

	if (!dev)
		return NULL;
	fwspec = dev_iommu_fwspec_get(dev);
	if (!fwspec || fwspec->ops != &riscv_iommu_ops ||
	    fwspec->num_ids != 1 || dev_is_pci(dev))
		return NULL;

	ep = dev_iommu_priv_get(dev);
	if (!ep || ep->dev != dev || ep->devid != fwspec->ids[0] ||
	    ep->devid > FIELD_MAX(RISCV_IOMMU_IOHPMEVT_DID_GSCID))
		return NULL;
	return ep;
}

/* All callers use the opt-in static single-mm current-platform contract. */
static bool riscv_iommu_research_ep_ok(struct riscv_iommu_endpoint *ep)
{
	u64 tc;

	if (!ep || !ep->dc || !ep->iommu || ep->pasid_enabled ||
	    (ep->devid != 10 && ep->devid != 11))
		return false;
	if (!(ep->iommu->cap & RISCV_IOMMU_CAP_S_SV39) ||
	    READ_ONCE(ep->iommu->research_cq_poisoned))
		return false;
	tc = le64_to_cpu(READ_ONCE(ep->dc->tc));
	return !(tc & (RISCV_IOMMU_DC_TC_EN_ATS | RISCV_IOMMU_DC_TC_EN_PRI |
		       RISCV_IOMMU_DC_TC_PDTV | RISCV_IOMMU_DC_TC_T2GPA |
		       RISCV_IOMMU_DC_TC_SXL)) &&
	       !le64_to_cpu(READ_ONCE(ep->dc->iohgatp));
}

bool riscv_iommu_research_supported(struct device *dev0, struct device *dev1)
{
	struct riscv_iommu_endpoint *ep0, *ep1;

	if (!research || !IS_ENABLED(CONFIG_64BIT) ||
	    IS_ENABLED(CONFIG_CPU_BIG_ENDIAN) ||
	    (satp_mode >> 60) != RISCV_IOMMU_DC_FSC_IOSATP_MODE_SV39)
		return false;
	ep0 = riscv_iommu_hpm_endpoint(dev0);
	ep1 = riscv_iommu_hpm_endpoint(dev1);
	return ep0 && ep1 && ep0 != ep1 && ep0->devid != ep1->devid &&
	       ep0->iommu == ep1->iommu &&
	       riscv_iommu_research_ep_ok(ep0) && riscv_iommu_research_ep_ok(ep1);
}
EXPORT_SYMBOL_GPL(riscv_iommu_research_supported);

struct iommu_domain *riscv_iommu_research_domain_alloc(struct device *dev,
						     struct mm_struct *mm)
{
	struct riscv_iommu_endpoint *ep = riscv_iommu_hpm_endpoint(dev);
	struct riscv_iommu_domain *domain;
	struct iommu_domain *core;
	int ret;

	if (!research || !IS_ENABLED(CONFIG_64BIT) ||
	    IS_ENABLED(CONFIG_CPU_BIG_ENDIAN) ||
	    (satp_mode >> 60) != RISCV_IOMMU_DC_FSC_IOSATP_MODE_SV39 ||
	    !riscv_iommu_research_ep_ok(ep))
		return ERR_PTR(-EOPNOTSUPP);
	if (mm && (mm != current->mm || !mm->pgd))
		return ERR_PTR(-EINVAL);
	core = iommu_domain_alloc(dev->bus);
	if (!core)
		return ERR_PTR(-ENOMEM);
	domain = iommu_domain_to_riscv(core);
	domain->research_domain = true;
	if (mm) {
		mmap_assert_locked(mm);
		mmget(mm);
		domain->borrowed_mm = mm;
		domain->pgd_borrowed = true;
		domain->pgd_root = mm->pgd;
	}
	mutex_lock(&domain->lock);
	ret = riscv_iommu_domain_finalize(domain, ep->iommu);
	mutex_unlock(&domain->lock);
	if (ret) {
		iommu_domain_free(core);
		return ERR_PTR(ret);
	}
	return core;
}
EXPORT_SYMBOL_GPL(riscv_iommu_research_domain_alloc);

int riscv_iommu_research_domain_release(struct iommu_domain *core)
{
	struct riscv_iommu_domain *domain;
	int ret = 0;

	if (!core || core->ops != &riscv_iommu_domain_ops)
		return -EINVAL;
	domain = iommu_domain_to_riscv(core);
	mutex_lock(&riscv_iommu_domain_mutex);
	mutex_lock(&domain->lock);
	if (!domain->research_domain)
		ret = -EINVAL;
	else if (!list_empty(&domain->endpoints))
		ret = -EBUSY;
	else if (domain->ever_attached &&
		 (READ_ONCE(domain->iommu->research_cq_poisoned) ||
		  READ_ONCE(domain->iommu->research_epoch) <=
					domain->retired_epoch))
		ret = -EIO;
	mutex_unlock(&domain->lock);
	mutex_unlock(&riscv_iommu_domain_mutex);
	/* Caller owns this unattached domain and serializes any future attach. */
	if (!ret)
		iommu_domain_free(core);
	return ret;
}
EXPORT_SYMBOL_GPL(riscv_iommu_research_domain_release);

#define RISCV_IOMMU_RESEARCH_CQ_ERRORS (RISCV_IOMMU_CQCSR_CQMF | \
	RISCV_IOMMU_CQCSR_CMD_TO | RISCV_IOMMU_CQCSR_CMD_ILL)
#define RISCV_IOMMU_RESEARCH_CQ_ON (RISCV_IOMMU_CQCSR_CQEN | RISCV_IOMMU_CQCSR_CQON)

int riscv_iommu_research_barrier(struct device *dev0, struct device *dev1,
				void (*sync_cache)(void *), void *sync_arg,
				struct riscv_iommu_research_certificate *cert)
{
	struct riscv_iommu_endpoint *ep0, *ep1, *first, *second;
	struct riscv_iommu_device *iommu;
	struct riscv_iommu_command cmd[5], *ring;
	unsigned long flags;
	unsigned long fresh_page;
	cycles_t start;
	u64 cqb, value, posted;
	u32 count, mask, head, tail, end, ctrl, token, i;
	s64 error_seq;
	int ret = -EIO;

	if (!sync_cache || !cert)
		return -EINVAL;
	memset(cert, 0, sizeof(*cert));
	if (!riscv_iommu_research_supported(dev0, dev1))
		return -EOPNOTSUPP;
	/* Allocation before locks; never share the 8-byte cell with another user. */
	fresh_page = get_zeroed_page(GFP_KERNEL);
	if (!fresh_page)
		return -ENOMEM;
	ep0 = riscv_iommu_hpm_endpoint(dev0);
	ep1 = riscv_iommu_hpm_endpoint(dev1);
	iommu = ep0->iommu;
	first = ep0->devid < ep1->devid ? ep0 : ep1;
	second = first == ep0 ? ep1 : ep0;
	mutex_lock(&first->lock);
	mutex_lock_nested(&second->lock, SINGLE_DEPTH_NESTING);
	if (!riscv_iommu_research_ep_ok(ep0) ||
	    !riscv_iommu_research_ep_ok(ep1) || ep1->iommu != iommu)
		goto unlock_endpoints;
	/* Core and endpoint identities must agree even on the restored default. */
	if (!ep0->domain || !ep1->domain ||
	    iommu_get_domain_for_dev(dev0) != &ep0->domain->domain ||
	    iommu_get_domain_for_dev(dev1) != &ep1->domain->domain)
		goto unlock_endpoints;

	spin_lock_irqsave(&iommu->cq_lock, flags);
	if (iommu->research_cq_owned || iommu->research_cq_poisoned) {
		ret = -EBUSY;
		goto unlock_cq;
	}
	count = iommu->cmdq.cnt;
	if (!iommu->cmdq.base || iommu->cmdq.in_iomem || count < 8 ||
	    !is_power_of_2(count) || iommu->cmdq.lui >= count)
		goto unlock_cq;
	mask = count - 1;
	cqb = riscv_iommu_readq(iommu, RISCV_IOMMU_REG_CQB);
	if (FIELD_GET(RISCV_IOMMU_QUEUE_SIZE_FIELD, cqb) >= 31 ||
	    (1ULL << (FIELD_GET(RISCV_IOMMU_QUEUE_SIZE_FIELD, cqb) + 1)) != count ||
	    ppn_to_phys(cqb) != iommu->cmdq.base_dma)
		goto unlock_cq;
	ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQCSR);
	if ((ctrl & RISCV_IOMMU_RESEARCH_CQ_ON) != RISCV_IOMMU_RESEARCH_CQ_ON ||
	    (ctrl & (RISCV_IOMMU_RESEARCH_CQ_ERRORS | RISCV_IOMMU_CQCSR_BUSY)))
		goto unlock_cq;
	head = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQH);
	tail = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQT);
	if (head >= count || tail != iommu->cmdq.lui ||
	    (iommu->cq_posted & mask) != tail ||
	    ((head - tail - 1) & mask) < ARRAY_SIZE(cmd)) {
		ret = -EBUSY;
		goto unlock_cq;
	}
	if (iommu->research_token == U32_MAX || iommu->research_epoch == U64_MAX ||
	    iommu->cq_posted > U64_MAX - ARRAY_SIZE(cmd)) {
		ret = -EOVERFLOW;
		goto unlock_cq;
	}
	if (!iommu->research_marker) {
		iommu->research_marker = (void *)fresh_page;
		fresh_page = 0;
	}
	token = ++iommu->research_token;
	error_seq = atomic64_read(&iommu->cq_error_seq);
	posted = iommu->cq_posted;
	iommu->research_cq_owned = true;
	spin_unlock_irqrestore(&iommu->cq_lock, flags);

	riscv_iommu_cmd_iodir_inval_ddt(&cmd[0]);
	riscv_iommu_cmd_iodir_set_did(&cmd[0], 10);
	riscv_iommu_cmd_iodir_inval_ddt(&cmd[1]);
	riscv_iommu_cmd_iodir_set_did(&cmd[1], 11);
	/* All host first-stage entries, including global entries. */
	riscv_iommu_cmd_inval_vma(&cmd[2]);
	riscv_iommu_cmd_iofence_set_av(&cmd[3],
					virt_to_phys(iommu->research_marker), token);
	riscv_iommu_cmd_iofence(&cmd[4]);
	WRITE_ONCE(*(u64 *)iommu->research_marker, cpu_to_le64(~(u64)token));
	ring = iommu->cmdq.base;
	for (i = 0; i < ARRAY_SIZE(cmd); i++)
		ring[(tail + i) & mask] = cmd[i];
	/* Accepted cache profile must make DC/PTE/commands/marker visible first. */
	sync_cache(sync_arg);
	wmb();
	end = (tail + ARRAY_SIZE(cmd)) & mask;
	spin_lock_irqsave(&iommu->cq_lock, flags);
	iommu->cmdq.lui = end;
	iommu->cq_posted += ARRAY_SIZE(cmd);
	riscv_iommu_writel(iommu, RISCV_IOMMU_REG_CQT, end);
	spin_unlock_irqrestore(&iommu->cq_lock, flags);

	start = get_cycles();
	for (;;) {
		sync_cache(sync_arg);
		value = le64_to_cpu(READ_ONCE(*(u64 *)iommu->research_marker));
		rmb();
		head = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQH);
		ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQCSR);
		if ((ctrl & RISCV_IOMMU_RESEARCH_CQ_ON) != RISCV_IOMMU_RESEARCH_CQ_ON ||
		    (ctrl & RISCV_IOMMU_RESEARCH_CQ_ERRORS) ||
		    atomic64_read(&iommu->cq_error_seq) != error_seq ||
		    riscv_iommu_readq(iommu, RISCV_IOMMU_REG_CQB) != cqb ||
		    riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQT) != end) {
			ret = -EIO;
			break;
		}
		if (value == (u64)token && head == end) {
			ret = 0;
			break;
		}
		if (get_cycles() - start > RISCV_IOMMU_TIMEOUT) {
			ret = -ETIMEDOUT;
			break;
		}
		cpu_relax();
	}
	spin_lock_irqsave(&iommu->cq_lock, flags);
	/* Keep error recovery excluded through the last acceptance observation. */
	ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQCSR);
	if (!ret && ((ctrl & RISCV_IOMMU_RESEARCH_CQ_ERRORS) ||
	    (ctrl & RISCV_IOMMU_RESEARCH_CQ_ON) != RISCV_IOMMU_RESEARCH_CQ_ON ||
	    atomic64_read(&iommu->cq_error_seq) != error_seq))
		ret = -EIO;
	if (ret)
		iommu->research_cq_poisoned = true;
	else
		WRITE_ONCE(iommu->research_epoch, iommu->research_epoch + 1);
	cert->epoch = iommu->research_epoch;
	cert->posted = posted;
	cert->cqb = cqb;
	cert->marker_phys = virt_to_phys(iommu->research_marker);
	cert->marker_value = value;
	cert->token = token;
	cert->first = tail;
	cert->head = head;
	cert->count = count;
	cert->cqcsr = ctrl;
	iommu->research_cq_owned = false;
unlock_cq:
	spin_unlock_irqrestore(&iommu->cq_lock, flags);
unlock_endpoints:
	mutex_unlock(&second->lock);
	mutex_unlock(&first->lock);
	if (fresh_page)
		free_page(fresh_page);
	return ret;
}
EXPORT_SYMBOL_GPL(riscv_iommu_research_barrier);

/*
 * Validate one acquire-time target under ep->lock. The acquire snapshot and
 * the endpoint's own domain must both still be the live "core" domain for
 * this device, the domain must belong to this IOMMU and use the ordinary
 * host S1 domain ops, and the device context must still match the domain's
 * live Sv39 root. Only plain ordinary (DMA or UNMANAGED) host first-stage
 * domains are accepted: SVA, identity, blocked, S2, nesting, PASID/PDTV and
 * the ATS/PRI/T2GPA/SXL DC bits are rejected. Called without domain->lock
 * (attach takes domain->lock before ep->lock), so domain->lock is never taken
 * here and no inversion is possible.
 */
static int riscv_iommu_flush_s1_check_ep(struct riscv_iommu_device *iommu,
					 struct riscv_iommu_endpoint *ep,
					 struct iommu_domain *snapshot)
{
	struct riscv_iommu_domain *domain;
	struct riscv_iommu_dc *dc;
	u64 tc, fsc, iohgatp;

	/*
	 * Resolve the device/domain identity before dereferencing the stored
	 * snapshot: the device must still report the same core domain and the
	 * endpoint must still point at that same domain object.
	 */
	if (!snapshot || iommu_get_domain_for_dev(ep->dev) != snapshot)
		return -ESTALE;
	if (!ep->domain || &ep->domain->domain != snapshot)
		return -ESTALE;

	domain = ep->domain;
	dc = ep->dc;

	if (domain->iommu != iommu)
		return -EXDEV;
	if (domain->domain.ops != &riscv_iommu_domain_ops)
		return -ESTALE;

	/*
	 * Ordinary host S1 only. IOMMU_DOMAIN_DMA / IOMMU_DOMAIN_UNMANAGED are
	 * the only accepted types; identity, blocked, SVA, DMA_FQ, S2, nesting
	 * and PASID are rejected as unsupported.
	 */
	if (domain->domain.type != IOMMU_DOMAIN_DMA &&
	    domain->domain.type != IOMMU_DOMAIN_UNMANAGED)
		return -EOPNOTSUPP;
	if (domain->g_stage || domain->nested || ep->pasid_enabled)
		return -EOPNOTSUPP;

	/*
	 * Sv39 requires IOSATP mode 8 with SXL == 0; mode 8 with SXL == 1
	 * would be Sv32 and is rejected through the DC check below.
	 */
	if (domain->mode != RISCV_IOMMU_DC_FSC_IOSATP_MODE_SV39)
		return -EOPNOTSUPP;
	if (!domain->pgd_root)
		return -EOPNOTSUPP;
	if (!dc)
		return -EOPNOTSUPP;

	tc = le64_to_cpu(dc->tc);
	fsc = le64_to_cpu(dc->fsc);
	iohgatp = le64_to_cpu(dc->iohgatp);

	if (!(tc & RISCV_IOMMU_DC_TC_V))
		return -EOPNOTSUPP;
	if (tc & (RISCV_IOMMU_DC_TC_EN_ATS | RISCV_IOMMU_DC_TC_EN_PRI |
		  RISCV_IOMMU_DC_TC_PDTV | RISCV_IOMMU_DC_TC_T2GPA |
		  RISCV_IOMMU_DC_TC_SXL))
		return -EOPNOTSUPP;
	if (FIELD_GET(RISCV_IOMMU_DC_IOHGATP_MODE, iohgatp) !=
	    RISCV_IOMMU_DC_IOHGATP_MODE_BARE)
		return -EOPNOTSUPP;

	/* The live device context must still describe this exact domain. */
	if (FIELD_GET(RISCV_IOMMU_DC_FSC_MODE, fsc) != domain->mode ||
	    FIELD_GET(RISCV_IOMMU_DC_FSC_PPN, fsc) !=
		    virt_to_pfn(domain->pgd_root))
		return -ESTALE;

	return 0;
}

/*
 * Global host first-stage invalidation barrier for one or two devices of the
 * same IOMMU. The caller owns the HPM session (hpm_lock), has quiesced the
 * relevant DMA and serializes binding changes. Both endpoint locks are held
 * across validation and command submission, taken in ascending device id
 * order, and no domain->lock is taken. This only issues IOTINVAL.VMA with
 * GV/AV/PSCV clear followed by a fence; it is not an ATS/PR/PW or general
 * internal-state reset, and it never retries or resets on failure.
 *
 * Note on the current RTL: CQH advances when the fetch of the last beat
 * completes, before decode. For this strict no-ATS/no-S2, quiesced
 * experiment the CQ decodes the earlier VMA (its invalidations are issued
 * before the fetch of the following IOFENCE), so CQH passing the following
 * fence is sufficient evidence that the VMA pulse was issued. This is not a
 * general fence-execution proof.
 */
int riscv_iommu_flush_s1_checked(struct riscv_iommu_device *iommu,
				 const struct riscv_iommu_s1_flush_target *targets,
				 unsigned int nr_targets)
{
	struct riscv_iommu_endpoint *ep[2] = { };
	struct riscv_iommu_command cmd;
	unsigned long flags;
	unsigned int first, second, i;
	u32 ctrl;
	s64 seq;
	int ret;

	if (!iommu || !targets || (nr_targets != 1 && nr_targets != 2))
		return -EINVAL;
	if (nr_targets == 2 &&
	    (targets[0].dev == targets[1].dev ||
	     targets[0].did == targets[1].did))
		return -EINVAL;

	for (i = 0; i < nr_targets; i++) {
		if (!targets[i].dev || !targets[i].domain)
			return -EINVAL;

		ep[i] = riscv_iommu_hpm_endpoint(targets[i].dev);
		if (!ep[i])
			return -EOPNOTSUPP;
		if (ep[i]->iommu != iommu)
			return -EXDEV;
		if (ep[i]->devid != targets[i].did)
			return -ESTALE;
	}
	if (nr_targets == 2 && ep[0] == ep[1])
		return -EINVAL;

	/* Take both endpoint mutexes, always in ascending device id order. */
	if (nr_targets == 2 && ep[0]->devid > ep[1]->devid) {
		first = 1;
		second = 0;
	} else {
		first = 0;
		second = nr_targets - 1;
	}
	mutex_lock(&ep[first]->lock);
	if (nr_targets == 2)
		mutex_lock_nested(&ep[second]->lock, SINGLE_DEPTH_NESTING);

	ret = 0;
	for (i = 0; i < nr_targets; i++) {
		/*
		 * Revalidate the endpoint identity under its lock, then let
		 * the core check compare the live domain against the stored
		 * acquire-time snapshot.
		 */
		if (ep[i]->dev != targets[i].dev ||
		    ep[i]->devid != targets[i].did ||
		    ep[i]->iommu != iommu) {
			ret = -ESTALE;
			break;
		}
		ret = riscv_iommu_flush_s1_check_ep(iommu, ep[i],
						    targets[i].domain);
		if (ret)
			break;
	}
	if (ret)
		goto unlock;

	/* Sample the error generation before looking at any CQ status. */
	seq = atomic64_read(&iommu->cq_error_seq);

	if (!iommu->cmdq.base || !iommu->cmdq.cnt ||
	    (iommu->cmdq.cnt & (iommu->cmdq.cnt - 1)) ||
	    iommu->cmdq.lui >= iommu->cmdq.cnt) {
		ret = -EIO;
		goto unlock;
	}

	ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQCSR);
	if (!(ctrl & RISCV_IOMMU_CQCSR_CQEN) ||
	    !(ctrl & RISCV_IOMMU_CQCSR_CQON) ||
	    (ctrl & (RISCV_IOMMU_CQCSR_CQMF | RISCV_IOMMU_CQCSR_CMD_TO |
		     RISCV_IOMMU_CQCSR_CMD_ILL))) {
		ret = -EIO;
		goto unlock;
	}

	/*
	 * Producer consistency, not a queue-empty claim: under cq_lock the
	 * software write cursor must match the hardware tail. Reading and
	 * comparing under the same lock keeps a concurrent poster from
	 * invalidating the observation; cq_lock is dropped immediately after.
	 */
	spin_lock_irqsave(&iommu->cq_lock, flags);
	if ((riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQT) &
	     (iommu->cmdq.cnt - 1)) != iommu->cmdq.lui)
		ret = -EIO;
	spin_unlock_irqrestore(&iommu->cq_lock, flags);
	if (ret)
		goto unlock;

	/* IOTINVAL.VMA with GV, AV and PSCV clear: every host S1 entry. */
	riscv_iommu_cmd_inval_vma(&cmd);
	if (!riscv_iommu_post(iommu, &cmd)) {
		ret = -EIO;
		goto unlock;
	}
	if (!riscv_iommu_iofence_sync(iommu)) {
		ret = -EIO;
		goto unlock;
	}

	/*
	 * End state must still be enabled and error-free. rmb() orders the
	 * final CQCSR read before the generation read so an IRQ thread that
	 * published the error and then cleared CQCSR is observed.
	 */
	ctrl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQCSR);
	rmb();
	if ((ctrl & (RISCV_IOMMU_CQCSR_CQEN | RISCV_IOMMU_CQCSR_CQON)) !=
		    (RISCV_IOMMU_CQCSR_CQEN | RISCV_IOMMU_CQCSR_CQON) ||
	    (ctrl & (RISCV_IOMMU_CQCSR_CQMF | RISCV_IOMMU_CQCSR_CMD_TO |
		     RISCV_IOMMU_CQCSR_CMD_ILL)) ||
	    atomic64_read(&iommu->cq_error_seq) != seq) {
		ret = -EIO;
		goto unlock;
	}

unlock:
	if (nr_targets == 2)
		mutex_unlock(&ep[second]->lock);
	mutex_unlock(&ep[first]->lock);
	return ret;
}

void riscv_iommu_remove(struct riscv_iommu_device *iommu)
{
	/* No teardown/reset is permitted over an uncertain marker write. */
	if (WARN_ON(READ_ONCE(iommu->research_cq_owned) ||
		    READ_ONCE(iommu->research_cq_poisoned)))
		return;
	/* An owner finishes restoring its HPM state before teardown proceeds. */
	mutex_lock(&iommu->hpm_lock);
	WRITE_ONCE(iommu->hpm_ready, false);
	mutex_unlock(&iommu->hpm_lock);
	iommu_device_unregister(&iommu->iommu);
	iommu_device_sysfs_remove(&iommu->iommu);
	riscv_iommu_enable(iommu, RISCV_IOMMU_DDTP_MODE_OFF);
	riscv_iommu_queue_free(iommu, &iommu->cmdq);
	riscv_iommu_queue_free(iommu, &iommu->fltq);
	riscv_iommu_queue_free(iommu, &iommu->priq);
	/* The clean removal path releases the per-IOMMU dedicated marker page. */
	if (iommu->research_marker &&
	    !(riscv_iommu_readl(iommu, RISCV_IOMMU_REG_CQCSR) &
	      (RISCV_IOMMU_CQCSR_CQON | RISCV_IOMMU_CQCSR_BUSY))) {
		free_page((unsigned long)iommu->research_marker);
		iommu->research_marker = NULL;
	}
	iopf_queue_free(iommu->pq_work);
}

int riscv_iommu_init(struct riscv_iommu_device *iommu)
{
	struct device *dev = iommu->dev;
	u32 fctl = 0;
	int ret;

	mutex_init(&iommu->hpm_lock);
	iommu->hpm_ready = false;
	iommu->eps = RB_ROOT;
	iommu->research_cq_owned = false;
	iommu->research_cq_poisoned = false;
	iommu->research_epoch = 0;
	iommu->cq_posted = 0;
	iommu->research_token = 0;
	iommu->research_marker = NULL;

	fctl = riscv_iommu_readl(iommu, RISCV_IOMMU_REG_FCTL);

#ifdef CONFIG_CPU_BIG_ENDIAN
	if (!(cap & RISCV_IOMMU_CAP_END)) {
		dev_err(dev, "IOMMU doesn't support Big Endian\n");
		return -EIO;
	} else if (!(fctl & RISCV_IOMMU_FCTL_BE)) {
		fctl |= FIELD_PREP(RISCV_IOMMU_FCTL_BE, 1);
		riscv_iommu_writel(iommu, RISCV_IOMMU_REG_FCTL, fctl);
	}
#endif

	/* Upper-half PSCIDs are private domains, so real PASIDs use 19 bits. */
	if (iommu->cap & RISCV_IOMMU_CAP_PD20)
		iommu->iommu.max_pasids = RISCV_IOMMU_DOMAIN_PSCID_MIN;
	else if (iommu->cap & RISCV_IOMMU_CAP_PD17)
		iommu->iommu.max_pasids = 1u << 17;
	else if (iommu->cap & RISCV_IOMMU_CAP_PD8)
		iommu->iommu.max_pasids = 1u << 8;
	/*
	 * Assign queue lengths from module parameters if not already
	 * set on the device tree.
	 */
	if (!iommu->cmdq_len)
	{
		iommu->cmdq_len = cmdq_length;		
		dev_info(dev, "CQ length: %d\n", cmdq_length);
	}
	if (!iommu->fltq_len)
	{
		iommu->fltq_len = fltq_length;
		dev_info(dev, "FQ length: %d\n", fltq_length);
	}
	if (!iommu->priq_len)
		iommu->priq_len = priq_length;
	/* Clear any pending interrupt flag. */
	riscv_iommu_writel(iommu, RISCV_IOMMU_REG_IPSR,
			   RISCV_IOMMU_IPSR_CIP |
			   RISCV_IOMMU_IPSR_FIP |
			   RISCV_IOMMU_IPSR_PMIP | RISCV_IOMMU_IPSR_PIP);
	spin_lock_init(&iommu->cq_lock);
	mutex_init(&iommu->eps_mutex);
	/* Initialize the error generation before any queue IRQ is requested. */
	atomic64_set(&iommu->cq_error_seq, 0);
	ret = riscv_iommu_queue_init(iommu, RISCV_IOMMU_COMMAND_QUEUE);
	if (ret)
		goto fail;
	ret = riscv_iommu_queue_init(iommu, RISCV_IOMMU_FAULT_QUEUE);
	if (ret)
		goto fail;
	if (!(iommu->cap & RISCV_IOMMU_CAP_ATS))
		goto no_ats;

	/**** ATS enabled: Start ****/

	/* PRI functionally depends on ATS’s capabilities. */
	if (!iommu->priq_len)
	{
		iommu->priq_len = priq_length;
		dev_info(dev, "PQ length: %d\n", priq_length);
	}

	iommu->pq_work = iopf_queue_alloc(dev_name(dev));
	if (!iommu->pq_work) {
		dev_err(dev, "failed to allocate iopf queue\n");
		ret = -ENOMEM;
		goto fail;
	}

	ret = riscv_iommu_queue_init(iommu, RISCV_IOMMU_PAGE_REQUEST_QUEUE);
	if (ret)
		goto fail;

	/**** ATS enabled: End ****/

 no_ats:

	// HPM
	if (iommu->cap & RISCV_IOMMU_CAP_HPM) {
		// Program HPM counters
		// Cnt 0: Untranslated requests
		riscv_iommu_writeq(iommu, RISCV_IOMMU_REG_IOHPMEVT(0), 
							(RISCV_IOMMU_IOHPMEVT_EVENT_ID & RISCV_IOMMU_EVENT_UT_REQ) |
							RISCV_IOMMU_IOHPMEVT_OF);
		// Cnt 1: TLB Misses
		riscv_iommu_writeq(iommu, RISCV_IOMMU_REG_IOHPMEVT(1), 
							(RISCV_IOMMU_IOHPMEVT_EVENT_ID & RISCV_IOMMU_EVENT_TLB_MISS) |
							RISCV_IOMMU_IOHPMEVT_OF);
		// Cnt 2: DDT Walks
		riscv_iommu_writeq(iommu, RISCV_IOMMU_REG_IOHPMEVT(2), 
							(RISCV_IOMMU_IOHPMEVT_EVENT_ID & RISCV_IOMMU_EVENT_DDTW) |
							RISCV_IOMMU_IOHPMEVT_OF);
		// Cnt 3: S1 PT Walks
		riscv_iommu_writeq(iommu, RISCV_IOMMU_REG_IOHPMEVT(3), 
							(RISCV_IOMMU_IOHPMEVT_EVENT_ID & RISCV_IOMMU_EVENT_S1_PTW) |
							RISCV_IOMMU_IOHPMEVT_OF);
		// Cnt 4: S2 PT Walks
		riscv_iommu_writeq(iommu, RISCV_IOMMU_REG_IOHPMEVT(4), 
							(RISCV_IOMMU_IOHPMEVT_EVENT_ID & RISCV_IOMMU_EVENT_S2_PTW) |
							RISCV_IOMMU_IOHPMEVT_OF);

		// Enable counters (... 1111 1100 0001)
		riscv_iommu_writel(iommu, RISCV_IOMMU_REG_IOCOUNTINH,
							(u32)(~0x3EUL));
	}

	if (iommu_default_passthrough()) {
		dev_info(dev, "iommu set to passthrough mode\n");
		ret = riscv_iommu_enable(iommu, RISCV_IOMMU_DDTP_MODE_BARE);
	} else {
		ret = riscv_iommu_enable(iommu, ddt_mode);
	}

	if (ret) {
		dev_err(dev, "cannot enable iommu device (%d)\n", ret);
		goto fail;
	}

	ret = riscv_iommu_sysfs_add(iommu);
	if (ret) {
		dev_err(dev, "cannot register sysfs interface (%d)\n", ret);
		goto fail;
	}

	WRITE_ONCE(iommu->hpm_ready, true);
	ret = iommu_device_register(&iommu->iommu, &riscv_iommu_ops, dev);
	if (ret) {
		dev_err(dev, "cannot register iommu interface (%d)\n", ret);
		iommu_device_sysfs_remove(&iommu->iommu);
		goto fail;
	}

	return 0;
 fail:
	WRITE_ONCE(iommu->hpm_ready, false);
	riscv_iommu_enable(iommu, RISCV_IOMMU_DDTP_MODE_OFF);
	riscv_iommu_queue_free(iommu, &iommu->priq);
	riscv_iommu_queue_free(iommu, &iommu->fltq);
	riscv_iommu_queue_free(iommu, &iommu->cmdq);
	iopf_queue_free(iommu->pq_work);
	return ret;
}
