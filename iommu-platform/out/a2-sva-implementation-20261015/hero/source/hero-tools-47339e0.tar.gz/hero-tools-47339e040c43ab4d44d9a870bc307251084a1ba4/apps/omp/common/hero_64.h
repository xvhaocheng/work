// Copyright 2019 ETH Zurich and University of Bologna.
// Licensed under the Apache License, Version 2.0, see LICENSE for details.
// SPDX-License-Identifier: Apache-2.0
//
// HERO 64-bit Addressing API

#ifndef __HERO_64_H__
#define __HERO_64_H__

#include <stdint.h>

/***************************************************************************************************
 * Public API
 **************************************************************************************************/

// This API provides loads and stores of 64-bit, 32-bit, 16-bit, and 8-bit unsigned integers to
// 64-bit addresses.  Each load and store exists in two variants:
// -  The blocking functions (no suffix) do not return until the memory access has succeeded.  Loads
//    return the loaded value.
// -  The non-blocking functions (`_noblock` suffix) return 0 on success and a non-zero value on
//    failure.  Loads pass the loaded value back through the `val` pointer.  The value stored in
//    `val` after a failing load is undefined.  It is illegal to let `val` point to a memory
//    location that might be unaccessible; violating this leads to undefined behavior. Moreover,
//    `val` has to be a native 32-bit device pointer as the load cannot be replaced recursively.
// Natively aligned 32-bit, 16-bit, and 8-bit memory accesses give rise to a single memory access
// operation and are thus single-copy atomic.  Unaligned or 64-bit memory accesses give rise to at
// least two memory access operations, and such loads from a memory location for which a race exists
// return an undefined value.
// For 64-bit memory accesses, the lower 32 bit are accessed before the upper 32 bit.  For the
// `uint64_noblock` functions, the upper 32 bit are always accessed (i.e., even if access to the
// lower 32 bit has failed), and the return value is the bitwise OR of the two `uint32_noblock`
// return values.
inline static __attribute__((used)) uint64_t hero_load_uint64(const uint64_t addr);
inline static __attribute__((used)) void hero_store_uint64(const uint64_t addr, const uint64_t val);
inline static __attribute__((used)) int hero_load_uint64_noblock(const uint64_t addr, __device uint64_t *const val);
inline static __attribute__((used)) int hero_store_uint64_noblock(const uint64_t addr, const uint64_t val);
inline static __attribute__((used)) uint32_t hero_load_uint32(const uint64_t addr);
inline static __attribute__((used)) void hero_store_uint32(const uint64_t addr, const uint32_t val);
inline static __attribute__((used)) int hero_load_uint32_noblock(const uint64_t addr, __device uint32_t *const val);
inline static __attribute__((used)) int hero_store_uint32_noblock(const uint64_t addr, const uint32_t val);
inline static __attribute__((used)) uint16_t hero_load_uint16(const uint64_t addr);
inline static __attribute__((used)) void hero_store_uint16(const uint64_t addr, const uint16_t val);
inline static __attribute__((used)) int hero_load_uint16_noblock(const uint64_t addr, __device uint16_t *const val);
inline static __attribute__((used)) int hero_store_uint16_noblock(const uint64_t addr, const uint16_t val);
inline static __attribute__((used)) uint8_t hero_load_uint8(const uint64_t addr);
inline static __attribute__((used)) void hero_store_uint8(const uint64_t addr, const uint8_t val);
inline static __attribute__((used)) int hero_load_uint8_noblock(const uint64_t addr, __device uint8_t *const val);
inline static __attribute__((used)) int hero_store_uint8_noblock(const uint64_t addr, const uint8_t val);

/***************************************************************************************************
 * Implementation Internals
 **************************************************************************************************/

#ifdef __HERO_DEV
// #include <snrt.h>
#else
#define snrt_printf(...)
#endif

#ifdef __HERO_DEV

#pragma clang diagnostic push
// NOTE: Clang currently incorrectly labels casts from integers to device pointers as being of different size
#pragma clang diagnostic ignored "-Wint-to-pointer-cast"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h> // abort()

inline static uint32_t __upper32(const uint64_t dw)
{
    return (uint32_t)(dw >> 32);
}

inline static uint32_t __lower32(const uint64_t dw)
{
    return (uint32_t)dw;
}

inline static void __loop_forever()
{
    while (1) {
        __asm__ volatile("nop" : : :);
    }
}

#define __hero_64_noblock_pre(data_t)                                                                                  \
    const uint32_t upper                  = __upper32(addr);                                                           \
    __device volatile data_t *const lower = (__device volatile data_t *)__lower32(addr);                               \
    uint32_t mstatus;

#define __hero_64_noblock_post return 0;

#define __hero_64_op_suffix(type, bits) __hero_64_op_suffix_##bits(type)
#define __hero_64_op_suffix_uint "u"
#define __hero_64_op_suffix_int
#define __hero_64_op_suffix_32(type) "w"
#define __hero_64_op_suffix_16(type) "h" __hero_64_op_suffix_##type
#define __hero_64_op_suffix_8(type) "b" __hero_64_op_suffix_##type

#define __hero_64_disable_mirq_asm "csrrci %[mstatus], 0x300, 3"
#define __hero_64_restore_mstatus_asm "csrrw x0, 0x300, %[mstatus]"

#define __hero_64_define_load_noblock(bits)                                                                            \
    inline static int hero_load_uint##bits##_noblock(const uint64_t addr, __device uint##bits##_t *const val)          \
    {                                                                                                                  \
        __hero_64_noblock_pre(uint##bits##_t) uint##bits##_t reg;                                                      \
        __asm__ volatile(                                                                                              \
            __hero_64_disable_mirq_asm                                                                                 \
            "\n\t"                 /*"csrw 0xbc0, %[upper]\n\t"  set upper 32 address bits in MSEG CSR */              \
            "csrw 0xbc0, zero\n\t" /* TODO: for now, set upper 32 address bits in MSEG CSR to zero to support 32-bit   \
                                      addresses only*/                                                                 \
            "l" __hero_64_op_suffix(uint, bits) " %[reg], 0(%[lower])\n\t" /* do actual load */                        \
                                                "csrw 0xbc0, zero\n\t" /* reset upper 32 address bits in MSEG CSR */   \
            __hero_64_restore_mstatus_asm                                                                              \
            : [reg] "=&r"(reg), [mstatus] "+&r"(mstatus)                                                               \
            : [upper] "r"(upper), [lower] "r"(lower)                                                                   \
            : "memory");                                                                                               \
        *val = reg;                                                                                                    \
        /* snrt_printf("[h64:%s] load @0x%016llx = %u 0x%08x to 0x%08x\r\n", __func__, addr, reg, reg, val); */        \
        __hero_64_noblock_post                                                                                         \
    }

#define __hero_64_define_store_noblock(bits)                                                                           \
    inline static int hero_store_uint##bits##_noblock(const uint64_t addr, const uint##bits##_t val)                   \
    {                                                                                                                  \
        __hero_64_noblock_pre(uint##bits##_t) __asm__ volatile(                                                        \
            __hero_64_disable_mirq_asm                                                                                 \
            "\n\t"                 /*"csrw 0xbc0, %[upper]\n\t"  set upper 32 address bits in MSEG CSR */              \
            "csrw 0xbc0, zero\n\t" /* TODO: for now, set upper 32 address bits in MSEG CSR to zero to support 32-bit   \
                                      addresses only*/                                                                 \
            "s" __hero_64_op_suffix(int, bits) " %[val], 0(%[lower])\n\t" /* do actual store */                        \
                                               "csrw 0xbc0, zero\n\t" /* reset upper 32 address bits in MSEG CSR */    \
            __hero_64_restore_mstatus_asm                                                                              \
            : [mstatus] "+&r"(mstatus)                                                                                 \
            : [upper] "r"(upper), [val] "r"(val), [lower] "r"(lower)                                                   \
            : "memory");                                                                                               \
        __hero_64_noblock_post                                                                                         \
    }

#define __hero_64_check_mem_access // TODO: handle misses

#define __hero_64_define_load(size)                                                                                    \
    inline static uint##size##_t hero_load_uint##size(const uint64_t addr)                                             \
    {                                                                                                                  \
        uint##size##_t val;                                                                                            \
        const int res = hero_load_uint##size##_noblock(addr, (__device uint##size##_t *)&val);                         \
        __hero_64_check_mem_access return val;                                                                         \
    }

#define __hero_64_define_store(size)                                                                                   \
    inline static void hero_store_uint##size(const uint64_t addr, const uint##size##_t val)                            \
    {                                                                                                                  \
        const int res = hero_store_uint##size##_noblock(addr, val);                                                    \
        __hero_64_check_mem_access                                                                                     \
    }

#define __hero_64_define(size)                                                                                         \
    __hero_64_define_load_noblock(size) __hero_64_define_load(size) __hero_64_define_store_noblock(size)               \
        __hero_64_define_store(size)

// FIXME: investigate error when this is put at start of the file
#pragma omp declare target
__hero_64_define(32) __hero_64_define(16) __hero_64_define(8)

    uint64_t hero_load_uint64(const uint64_t addr)
{
    const uint32_t lower = hero_load_uint32(addr);
    const uint32_t upper = hero_load_uint32(addr + 4);
    uint64_t ret_val     = ((uint64_t)upper << 32) | lower;
    // printf("RET: %x %x %llx\n", lower, upper, ret_val);
    return ret_val;
}

void hero_store_uint64(const uint64_t addr, const uint64_t val)
{
    const uint32_t lower = (uint32_t)val;
    hero_store_uint32(addr, lower);
    const uint32_t upper = (uint32_t)(val >> 32);
    hero_store_uint32(addr + 4, upper);
}

int hero_load_uint64_noblock(const uint64_t addr, __device uint64_t *const val)
{
    __device uint32_t *const lower = (__device uint32_t *)val;
    const int res_lower            = hero_load_uint32_noblock(addr, lower);
    __device uint32_t *const upper = lower + 1;
    const int res_upper            = hero_load_uint32_noblock(addr + 4, upper);
    return res_lower | res_upper;
}

int hero_store_uint64_noblock(const uint64_t addr, const uint64_t val)
{
    const uint32_t lower = (uint32_t)val;
    const int res_lower  = hero_store_uint32_noblock(addr, lower);
    const uint32_t upper = (uint32_t)(val >> 32);
    const int res_upper  = hero_store_uint32_noblock(addr + 4, upper);
    return res_lower | res_upper;
}
#pragma omp end declare target

#pragma clang diagnostic pop

#endif // #ifdef __HERO_DEV

#endif
